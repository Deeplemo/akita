# Crawling Strategies Reference

Decision flowcharts and common crawling patterns.

## Strategy Decision Flowchart

```
START: What do you need to crawl?
│
├─ Static HTML page (no JS needed)
│   ├─ First try: requests + BeautifulSoup
│   │   ├─ 200 OK → DONE ✅
│   │   ├─ 403 Forbidden → Check anti-bot
│   │   ├─ Cloudflare challenge → Use curl_cffi or Scrapling
│   │   └── Rate limited (429) → Add delays + rotate proxies
│   │
│   └─ curl_cffi / Scrapling
│       ├─ 200 OK → DONE ✅
│       └─ Still blocked → Escalate to browser automation
│
├─ JavaScript-rendered page (SPA, React, Vue)
│   ├─ First try: Playwright + stealth
│   │   ├─ Page loads correctly → DONE ✅
│   │   ├─ Detected as bot → Try camoufox or undetected-chromedriver
│   │   └─ Cloudflare challenge → Use stealth plugin + wait
│   │
│   └─ Alternative: Intercept API calls directly
│       ├─ Open browser DevTools → Network tab
│       ├─ Find the XHR/Fetch API endpoint
│       ├─ Replicate the request with curl_cffi
│       └─ Parse JSON response → DONE ✅ (much faster than browser)
│
├─ Login-protected page
│   ├─ Simple auth → requests Session with cookies
│   ├─ JS-rendered login → Playwright with login flow
│   └─ OAuth/Social login → agent-browser (manual) or Playwright
│
├─ Large-scale crawling (1000+ pages)
│   ├─ Use Scrapy with:
│   │   ├── scrapy-playwright for JS rendering
│   │   ├── Rotating proxy middleware
│   │   ├── AutoThrottle for rate limiting
│   │   └── Item pipelines for data storage
│   │
│   └─ Distribute with:
│       ├── scrapy-redis for distributed crawling
│       └── Multiple proxy pools
│
└─ CAPTCHA-protected page
    ├─ Solve automatically → 2Captcha / CapSolver API
    ├─ Semi-automated → agent-browser (solve manually, extract cookies)
    └─ Avoid (find API endpoint instead)
```

## Common Patterns

### Pattern 1: Pagination Crawling
```python
from curl_cffi import requests
import time, random

session = requests.Session(impersonate='chrome131')

for page in range(1, 100):
    url = f'https://example.com/items?page={page}'
    resp = session.get(url)
    
    # Check for end of pagination
    if resp.status_code == 404 or 'No results' in resp.text:
        break
    
    # Process page...
    time.sleep(random.uniform(2, 5))
```

### Pattern 2: Infinite Scroll
```python
from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    stealth_sync(page)
    page.goto('https://example.com/feed')
    
    all_items = []
    prev_count = 0
    
    while True:
        page.evaluate('window.scrollBy(0, document.body.scrollHeight)')
        page.wait_for_timeout(2000)
        
        items = page.query_selector_all('div.item')
        all_items.extend([item.text_content() for item in items])
        
        if len(items) == prev_count:
            break
        prev_count = len(items)
    
    browser.close()
```

### Pattern 3: API Interception (Fastest Method)
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    
    api_responses = []
    
    def handle_response(response):
        if '/api/v1/' in response.url and response.status == 200:
            try:
                api_responses.append(response.json())
            except:
                pass
    
    page.on('response', handle_response)
    page.goto('https://example.com')
    page.wait_for_timeout(5000)
    
    # Now you have the raw API data - no HTML parsing needed!
    import json
    for data in api_responses:
        print(json.dumps(data, indent=2))
    
    browser.close()
```

Then recreate the API call directly:
```python
from curl_cffi import requests

# Use the intercepted API URL and headers directly
resp = requests.get(
    'https://example.com/api/v1/items',
    headers={'Authorization': 'Bearer ...', 'X-API-Key': '...'},
    impersonate='chrome131'
)
```

### Pattern 4: Authenticated Session Persistence
```python
import requests, os, json

SESSION_FILE = 'session.json'

def get_session():
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    })
    
    if os.path.exists(SESSION_FILE):
        cookies = json.load(open(SESSION_FILE))
        for k, v in cookies.items():
            session.cookies.set(k, v)
    
    resp = session.get('https://example.com/dashboard')
    if 'login' in resp.url.lower():
        # Session expired, re-login
        login(session)
    
    return session

def login(session):
    # Get CSRF token
    resp = session.get('https://example.com/login')
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(resp.text, 'lxml')
    csrf = soup.select_one('input[name=csrf_token]')['value']
    
    # Submit login
    session.post('https://example.com/login', data={
        'username': 'user',
        'password': 'pass',
        'csrf_token': csrf,
    })
    
    # Persist cookies
    json.dump(dict(session.cookies), open(SESSION_FILE, 'w'))

def save_session(session):
    json.dump(dict(session.cookies), open(SESSION_FILE, 'w'))
```

### Pattern 5: Proxy Rotation with Retry
```python
import random, time
from curl_cffi import requests

PROXIES = [
    'http://proxy1:8080',
    'http://proxy2:8080',
    'http://proxy3:8080',
]

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/131.0.0.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0',
]

def fetch_with_retry(url, max_retries=3):
    for attempt in range(max_retries):
        proxy = random.choice(PROXIES)
        ua = random.choice(USER_AGENTS)
        
        try:
            session = requests.Session(impersonate='chrome131')
            resp = session.get(
                url,
                proxies={'https': proxy},
                headers={'User-Agent': ua},
            )
            
            if resp.status_code == 200:
                return resp
            elif resp.status_code == 429:
                wait = (2 ** attempt) + random.uniform(0, 1)
                time.sleep(wait)
            else:
                time.sleep(random.uniform(1, 3))
        except Exception as e:
            print(f'Attempt {attempt + 1} failed: {e}')
            time.sleep(random.uniform(2, 5))
    
    return None
```

### Pattern 6: Cloudflare Bypass with Playwright
```python
from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync

def bypass_cloudflare(url):
    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=['--disable-blink-features=AutomationControlled']
        )
        context = browser.new_context(
            user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/131.0.0.0 Safari/537.36',
        )
        page = context.new_page()
        stealth_sync(page)
        
        page.goto(url, wait_until='networkidle', timeout=60000)
        
        # Wait for Cloudflare challenge to complete
        page.wait_for_timeout(10000)
        
        # Check if still on challenge page
        if 'Just a moment' in page.title():
            page.wait_for_timeout(15000)
        
        content = page.content()
        cookies = context.cookies()
        browser.close()
        return content, cookies
```

### Pattern 7: Data Extraction with Selectors
```python
from bs4 import BeautifulSoup
import json

def extract_data(html, selectors):
    """
    selectors = {
        'title': {'type': 'css', 'value': 'h1.title'},
        'price': {'type': 'xpath', 'value': '//span[@class="price"]/text()'},
        'items': {'type': 'css', 'value': 'div.item', 'multiple': True, 'children': {
            'name': {'type': 'css', 'value': 'h3'},
            'link': {'type': 'css', 'value': 'a', 'attr': 'href'},
        }},
    }
    """
    soup = BeautifulSoup(html, 'lxml')
    result = {}
    
    for key, selector in selectors.items():
        elements = soup.select(selector['value'])
        
        if selector.get('multiple'):
            result[key] = []
            for el in elements:
                item = {}
                for child_key, child_sel in selector.get('children', {}).items():
                    child_el = el.select_one(child_sel['value'])
                    item[child_key] = child_el.get(child_sel.get('attr', 'text'), '').strip() if child_el else None
                result[key].append(item)
        else:
            el = elements[0] if elements else None
            if el:
                if selector.get('attr'):
                    result[key] = el.get(selector['attr'], '').strip()
                else:
                    result[key] = el.get_text(strip=True)
            else:
                result[key] = None
    
    return result
```

## Error Handling Patterns

### Exponential Backoff
```python
import time, random

def fetch_with_backoff(url, session, max_retries=5):
    for attempt in range(max_retries):
        try:
            resp = session.get(url)
            if resp.status_code == 200:
                return resp
            elif resp.status_code == 429:
                wait = (2 ** attempt) + random.uniform(0, 1)
                print(f'Rate limited. Waiting {wait:.1f}s...')
                time.sleep(wait)
            elif resp.status_code in [403, 503]:
                print(f'Blocked ({resp.status_code}). Rotating...')
                time.sleep(random.uniform(5, 15))
            else:
                resp.raise_for_status()
        except Exception as e:
            print(f'Error: {e}. Retrying...')
            time.sleep((2 ** attempt) + random.uniform(0, 1))
    return None
```

### Anti-Detection Monitoring
```python
def check_for_blocks(resp, content):
    """Check if response indicates anti-bot blocking."""
    indicators = {
        'cloudflare': ['cf-challenge', 'Just a moment', 'cf-browser-verification'],
        'datadome': ['datadome', 'DataDome'],
        'perimeterx': ['_px3', 'PerimeterX'],
        'recaptcha': ['g-recaptcha', 'recaptcha'],
        'hcaptcha': ['h-captcha', 'hcaptcha'],
        'generic': ['bot detection', 'access denied', 'unusual traffic'],
    }
    
    for name, patterns in indicators.items():
        for pattern in patterns:
            if pattern.lower() in content.lower() or pattern.lower() in str(resp.headers).lower():
                return f'Blocked by: {name}'
    
    return None
```

## Data Storage Patterns

### JSON Lines (incremental, good for large crawls)
```python
import json

def save_item(item, filepath='output.jsonl'):
    with open(filepath, 'a', encoding='utf-8') as f:
        f.write(json.dumps(item, ensure_ascii=False) + '\n')

def read_items(filepath='output.jsonl'):
    items = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            items.append(json.loads(line))
    return items
```

### CSV Output
```python
import csv

def save_to_csv(items, filepath='output.csv', fieldnames=None):
    if items and not fieldnames:
        fieldnames = items[0].keys()
    
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(items)
```