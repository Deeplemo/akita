# Crawler Frameworks Reference (2025)

**Philosophy: Use existing wheels, don't reinvent them.**

## Quick Selection Guide

```
What do you need?
├── General web scraping (any site)
│   └── Scrapling (Fetcher → StealthyFetcher → DynamicFetcher)
├── Chinese platforms (social/short-video/Q&A/forums)
│   └── MediaCrawler (ready-made, 47k⭐)
├── LLM/Markdown extraction
│   └── Crawl4AI
├── Cloudflare/Datadome bypass
│   └── Scrapling StealthyFetcher or Botasaurus
├── TLS fingerprint bypass only
│   └── curl_cffi
├── Browser automation (no WebDriver)
│   └── DrissionPage
├── Firefox stealth (DataDome/PerimeterX)
│   └── camoufox
├── Interactive debugging / CAPTCHA
│   └── agent-browser
└── Large-scale distributed crawling
    └── Scrapy + scrapy-playwright
```

## Framework Comparison

| Framework | Stars | Anti-Bot | JS Render | Parser | Best For |
|---|---|---|---|---|---|
| **Scrapling** | 35k⭐ | ✅ Turnstile bypass | ✅ DynamicFetcher | Adaptive (780x faster than BS4) | **Default choice for all scraping** |
| **MediaCrawler** | 47.5k⭐ | ✅ Platform-specific | ✅ Playwright | Built-in | **Chinese platforms only** |
| **Crawl4AI** | 63.6k⭐ | ✅ 3-tier detection | ✅ Playwright | Markdown/HTML | **LLM/Markdown extraction** |
| **Botasaurus** | ~3k⭐ | ✅ CF/Datadome | ✅ Chrome Driver | BS4 | **Cloudflare bypass, UI generation** |
| **curl_cffi** | 5.4k⭐ | ✅ TLS impersonation | ❌ | N/A | **HTTP-only TLS bypass** |
| **DrissionPage** | 11.7k⭐ | ✅ No WebDriver | ✅ CDP | lxml | **Chinese sites, no detection** |
| **camoufox** | 6.8k⭐ | ✅ C++ fingerprint | ✅ Firefox | Playwright | **DataDome/PerimeterX bypass** |
| **Playwright** | 70k⭐ | ⚠️ stealth plugin | ✅ Chromium | CSS/XPath | **JS-heavy sites with stealth** |
| **Scrapy** | 53k⭐ | ⚠️ middleware | ✅ scrapy-playwright | Parsel/BS4 | **Distributed crawling** |
| **agent-browser** | — | ⚠️ manual | ✅ Chrome | CLI | **Interactive/CAPTCHA** |

## Tool Details

### 1. Scrapling ⭐ RECOMMENDED DEFAULT

**Install:** `pip install scrapling` or `pip install scrapling[all]` (includes stealth)

**Why it's the default:**
- 780x faster than BeautifulSoup (lxml-based)
- Adaptive element finding that survives page structure changes
- 3 fetcher modes: Fetcher (HTTP), StealthyFetcher (anti-bot), DynamicFetcher (full browser)
- Built-in Cloudflare Turnstile bypass with `solve_cloudflare=True`
- Scrapy-like Spider framework for crawling

```python
from scrapling import Fetcher, StealthyFetcher

# Static page (fast HTTP)
page = Fetcher().get('https://example.com')
titles = page.css('h2.title::text').getall()

# Cloudflare-protected page
page = StealthyFetcher.fetch('https://protected.com', headless=True, solve_cloudflare=True)

# Adaptive finding (survives page changes)
item = page.find_by_text('Buy Now')  # finds even if CSS changes
```

**Impersonation options:** `chrome131`, `chrome124`, `chrome120`, `chrome116`, `safari17_0`, `edge101`

### 2. MediaCrawler ⭐ FOR CHINESE PLATFORMS

**Install:** `git clone https://github.com/NanmiCoder/MediaCrawler.git && cd MediaCrawler && pip install -r requirements.txt`

**Platforms:** Major Chinese social, short-video, Q&A, and forum platforms

```bash
# Crawl social commerce platform
python main.py --platform xhs --lt qrcode --type search --keyword "AI"

# Crawl microblogging platform
python main.py --platform wb --lt qrcode --type search --keyword "trending"

# Crawl Q&A platform
python main.py --platform zs --lt qrcode --type search --keyword "AI"
```

### 3. Crawl4AI ⭐ FOR LLM/Markdown

**Install:** `pip install crawl4ai`

```python
import asyncio
from crawl4ai import AsyncWebCrawler

async def main():
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url="https://example.com")
        print(result.markdown)  # Clean markdown output
        
        # Structured extraction with CSS schema
        from crawl4ai import JsonCssExtractionStrategy
        strategy = JsonCssExtractionStrategy(schema={
            "name": "articles",
            "baseSelector": "div.article",
            "fields": [{"name": "title", "selector": "h2"}, {"name": "link", "selector": "a", "attribute": "href"}]
        })

asyncio.run(main())
```

### 4. curl_cffi

**Install:** `pip install curl_cffi`

```python
from curl_cffi import requests

# TLS fingerprint bypass — when Scrapling Fetcher isn't enough
resp = requests.get('https://example.com', impersonate='chrome131')
```

### 5. DrissionPage ⭐ FOR CHINESE SITES

**Install:** `pip install DrissionPage`

```python
from DrissionPage import ChromiumPage

page = ChromiumPage()
page.get('https://example.com')
# No WebDriver detection — uses CDP directly
element = page.ele('text:Login')
```

### 6. Botasaurus

**Install:** `pip install botasaurus`

```python
from botasaurus.browser import browser, Driver

@browser
def scrape(driver: Driver, data):
    driver.google_get("https://protected-site.com", bypass_cloudflare=True)
    heading = driver.get_text("h1")
    return {"heading": heading}

scrape()
```

### 7. camoufox

**Install:** `pip install camoufox && python3 -m camoufox fetch`

```python
from camoufox.sync_api import Camoufox

with Camoufox(headless=True) as browser:
    page = browser.new_page()
    page.goto('https://datadome-protected.com')
    # C++ level fingerprint randomization
```

### 8. Scrapy (Distributed Crawling)

**Install:** `pip install scrapy scrapy-playwright`

Use only for large-scale (1000+ page) distributed crawling. Overkill for most single-site tasks.

## Parser Speed Comparison

| Parser | Time (5000 elements) | Notes |
|---|---|---|
| **Scrapling** | 2.02ms | Adaptive finding, CSS+XPath+regex |
| **Parsel** | 2.04ms | Scrapy standard, CSS+XPath |
| **lxml** | 2.54ms | XPath only, lowest level |
| **PyQuery** | 24.17ms | jQuery-like API |
| **Selectolax** | 82.63ms | C-based, CSS only |
| **BeautifulSoup+lxml** | 1584ms | Most popular, very slow |
| **BeautifulSoup+html5lib** | 3392ms | Most lenient, extremely slow |