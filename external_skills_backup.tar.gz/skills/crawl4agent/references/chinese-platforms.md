# Chinese Platform Crawling Reference

Guide for crawling Chinese web platforms that implement heavy anti-bot protections.

## The Best Tool: MediaCrawler

**MediaCrawler** (47k+ ⭐) is the #1 open-source tool for Chinese platform scraping.
It provides **ready-made** scrapers for all major platforms — **do not write custom scrapers** unless MediaCrawler doesn't cover your needs.

**GitHub:** https://github.com/NanmiCoder/MediaCrawler

### Supported Platform Types

| Platform Type | Keyword | Crawl Types |
|---|---|---|
| Social commerce | `xhs` | Search, detail, comments, creator |
| Short video | `dy` | Search, detail, comments, creator |
| Another short video | `ks` | Search, detail, comments |
| Video community | `bli` | Search, detail, comments |
| Microblogging | `wb` | Search, detail, comments, creator |
| Forum | `forum` | Search, posts, comments |
| Q&A | `zs` | Search, detail, comments |

### Installation & Usage

```bash
# Clone and install
git clone https://github.com/NanmiCoder/MediaCrawler.git
cd MediaCrawler
pip install -r requirements.txt

# Crawl social commerce platform (keyword search)
python main.py --platform xhs --lt qrcode --type search --keyword "AI"

# Crawl short video platform
python main.py --platform dy --lt qrcode --type search --keyword "painting"

# Crawl microblogging platform
python main.py --platform wb --lt qrcode --type search --keyword "trending"

# Crawl Q&A platform
python main.py --platform zs --lt qrcode --type search --keyword "AI"

# Crawl video community
python main.py --platform bli --lt qrcode --type search --keyword "tutorial"

# Crawl creator's posts
python main.py --platform xhs --lt qrcode --type creator --creator_id xxx

# Enable proxy rotation
python main.py --platform xhs --lt qrcode --type search --keyword "AI" --proxy_ip proxy.example.com:8080
```

### Login Methods

| `--lt` Value | Login Method |
|---|---|
| `qrcode` | QR code scan (recommended) |
| `cookie` | Paste cookie string |
| `phone` | Phone number + SMS code |

### Configuration

Edit `config/base_config.py`:
```python
# Headless mode
HEADLESS = False  # Set True for server

# Browser type
BROWSER_TYPE = "chromium"  # or "firefox"

# Data save options
SAVE_DATA_OPTION = "db"  # "db" for MySQL, "csv", or "json"

# Crawl limits
CRAWLER_MAX_NOTES_COUNT = 50  # Max posts per run
CRAWLER_MAX_COMMENTS_COUNT = 100  # Max comments per post
```

## Anti-Bot Characteristics by Platform Type

### Social Commerce Platforms
- **Anti-bot**: CDN/WAF + JS signature parameters (`x-s`/`x-t` type)
- **Login required**: Yes (QR code or cookie)
- **Protection level**: HIGH
- **Best approach**: MediaCrawler (uses Playwright for login + JS signature generation)
- **Alternative**: DrissionPage for custom scripts

### Short Video Platforms
- **Anti-bot**: Custom signature + device fingerprinting
- **Login required**: Partial (search works without login, but limited)
- **Protection level**: HIGH
- **Best approach**: MediaCrawler

### Microblogging Platforms
- **Anti-bot**: Passport auth gate + custom WAF fingerprinting
- **Login required**: Yes (passport redirect)
- **Protection level**: HIGH
- **Best approach**: MediaCrawler (handles login + session management)
- **Alternative**: DrissionPage for manual login + cookie extraction

### Q&A Platforms
- **Anti-bot**: Encrypted signatures + WAF
- **Login required**: Yes (redirects to /signin)
- **Protection level**: HIGH
- **Best approach**: MediaCrawler

### Video Community Platforms
- **Anti-bot**: WBI-type signature + device fingerprinting
- **Login required**: Partial (some content accessible without login)
- **Protection level**: MEDIUM-HIGH
- **Best approach**: MediaCrawler

### Tech Community Platforms
- **Anti-bot**: WAFJS + SHA-256 proof-of-work challenge
- **Login required**: No (but JS challenge must pass)
- **Protection level**: HIGH
- **Best approach**: Scrapling `StealthyFetcher` or DrissionPage

## Proxy Pool

**ProxyPool** (23k+ ⭐) — Free proxy pool with Redis storage.

```bash
git clone https://github.com/jhao104/proxy_pool.git
cd proxy_pool && pip install -r requirements.txt
# Start Redis, then:
python proxyPool.py schedule  # Fetch proxies
python proxyPool.py server     # API server on :5010
# Get proxy: http://127.0.0.1:5010/get_proxy
```

Note: Free proxies are unreliable. For production use, consider paid proxy services.

## Anti-Bot Signature Types

| Signature Type | Parameters | Algorithm |
|---|---|---|
| Social commerce | `x-s`, `x-t` | SHA-256 + timestamp; generated in JS |
| Short video | `X-Bogus`, `A_Bogus` | MD5 + payload encryption |
| Video community | `wbi` | IMG key + sub key from nav API |
| Q&A | `x-zse-93`, `x-zse-96` | AES-encrypted with versioned key |
| Tech community | `_wafchallengeid` | SHA-256 proof-of-work challenge |

**Recommendation**: Use MediaCrawler for platforms with custom signatures — it already implements all signature algorithms.

## MediaCrawler vs. Custom Script: Decision Criteria

| Scenario | Choose |
|---|---|
| Need batch crawling + persistent storage | MediaCrawler |
| Need ready-made login/signature handling | MediaCrawler |
| Need <50 items with custom extraction logic | Custom DrissionPage script |
| Need to integrate into larger pipeline | Custom script |
| Platform not covered by MediaCrawler | Custom script |
| Quick one-time data extraction | Custom script |
