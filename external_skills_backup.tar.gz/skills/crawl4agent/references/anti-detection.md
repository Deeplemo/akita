# Anti-Bot Detection & Bypass Reference

Complete reference for detecting and bypassing anti-bot protections.

## Detection Techniques Used by Websites

### 1. HTTP Header Analysis
Websites check for suspicious header patterns:
- Missing or default `User-Agent`
- Non-standard header ordering
- Missing `Accept`, `Accept-Language`, `Accept-Encoding`
- Python-requests default headers (`requests/2.x`)

**Bypass:**
```python
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'DNT': '1',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Cache-Control': 'max-age=0',
}
```

### 2. TLS/JA3 Fingerprinting
Servers fingerprint TLS handshake to detect non-browser clients. Python's `requests` library has a distinct TLS fingerprint.

**Bypass:** Use `curl_cffi` which impersonates browser TLS fingerprints:
```python
from curl_cffi import requests

resp = requests.get('https://example.com', impersonate='chrome131')
```

Impersonation options: `chrome99`, `chrome100`, `chrome101`, `chrome104`, `chrome107`, `chrome110`, `chrome116`, `chrome119`, `chrome120`, `chrome123`, `chrome124`, `edge99`, `edge101`, `safari15_3`, `safari15_5`, `safari17_0`

### 3. JavaScript Challenges
Server returns HTML with embedded JS that must execute to produce a cookie or redirect token.

**Detection signs:**
- Response contains `<script>` with `document.cookie` or `window.location`
- HTTP status 403 with JS challenge page
- Cloudflare "Checking your browser" page

**Bypass:** Use browser automation:
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    page.goto('https://example.com')
    page.wait_for_load_state('networkidle')
    content = page.content()
    browser.close()
```

### 4. Browser Fingerprinting
Websites run JS to collect:
- `navigator.webdriver` (set to `true` in automated browsers)
- Canvas fingerprint
- WebGL fingerprint
- Audio context fingerprint
- Screen resolution & color depth
- Installed plugins & fonts
- `window.chrome` presence
- `Notification.permission` behavior
- `navigator.languages` array

**Bypass with Playwright stealth:**
```python
from playwright_stealth import stealth_sync

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    page = browser.new_page()
    stealth_sync(page)
    page.goto('https://example.com')
```

**Bypass with undetected-chromedriver:**
```python
import undetected_chromedriver as uc

driver = uc.Chrome()
driver.get('https://example.com')
```

**Bypass with camoufox (Firefox-based):**
```python
from camoufox.sync_api import Camoufox

with Camoufox(headless=True) as browser:
    page = browser.new_page()
    page.goto('https://example.com')
    print(page.title())
```

### 5. CAPTCHA Systems

| CAPTCHA Type | Detection | Bypass Strategy |
|---|---|---|
| reCAPTCHA v2 | "I'm not a robot" checkbox | 2Captcha API, agent-browser manual solve |
| reCAPTCHA v3 | Invisible score-based | 2Captcha API, session warmup |
| hCaptcha | Visual puzzle | 2Captcha API, CapSolver |
| Cloudflare Turnstile | Cloudflare invisible challenge | camoufox, Playwright stealth |
| GeeTest | Slide/click puzzle | GeeTest solver APIs |

**2Captcha integration:**
```python
import requests

API_KEY = 'your_2captcha_key'
site_key = '6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0abA8v0zb'
page_url = 'https://example.com'

resp = requests.post('https://2captcha.com/in.php', data={
    'key': API_KEY,
    'method': 'userrecaptcha',
    'googlekey': site_key,
    'pageurl': page_url,
})
task_id = resp.text.split('|')[1]

import time
while True:
    time.sleep(5)
    result = requests.get(f'https://2captcha.com/res.php?key={API_KEY}&action=get&id={task_id}').text
    if 'CAPCHA_NOT_READY' not in result:
        captcha_token = result.split('|')[1]
        break
```

### 6. IP Rate Limiting & Blocks
Servers track request frequency per IP and block suspicious patterns.

**Bypass strategies:**
- **Rate limiting**: Add random delays (2-8 seconds between requests)
- **IP rotation**: Use proxy pools
- **Session distribution**: Rotate cookies and sessions

```python
import random, time

for url in urls:
    time.sleep(random.uniform(2, 8))
    session.get(url, proxies={'https': f'http://proxy-{random.randint(1,100)}:8080'})
```

### 7. Cookie & Session Tracking
Servers set tracking cookies and flag sessions with unrealistic browsing patterns.

**Bypass:**
- Always accept and persist cookies
- Visit the homepage before target pages (referral pattern)
- Add realistic delay between page transitions
- Don't visit pages in alphabetical/sequential order

### 8. Behavioral Analysis
Advanced systems detect non-human browsing patterns:
- Sub-second page transitions
- No mouse movement or scroll events
- Identical time between actions
- Direct URL access without navigation path

**Bypass with Playwright:**
```python
def human_like_browse(page, url):
    page.goto(url)
    page.wait_for_timeout(random.randint(1000, 3000))
    page.mouse.move(random.randint(100, 500), random.randint(100, 500))
    page.evaluate('window.scrollBy(0, window.innerHeight)')
    page.wait_for_timeout(random.randint(500, 2000))
```

## Specific Anti-Bot Services

### Cloudflare
- **JS Challenge**: Returns 403 with JS challenge → Use Playwright stealth or scrapling
- **Turnstile CAPTCHA**: Interactive challenge → Use camoufox or 2Captcha
- **Under Attack Mode**: Aggressive JS checking → Use `curl_cffi` with impersonation
- **WAF Rules**: IP/behavioral blocking → Rotate proxies, slow down requests

```python
# Best approach: scrapling (handles most Cloudflare automatically)
from scrapling import Fetcher
page = Fetcher(auto_match=False).get('https://cloudflare-protected.com')
```

### DataDome
- Advanced device fingerprinting
- Server-side and client-side detection
- **Bypass**: `undetected-chromedriver` or `camoufox` with session warmup

### PerimeterX (now HUMAN)
- Behavioral JS analysis
- `._px3` cookie validation
- **Bypass**: `Playwright` with stealth, or reverse-engineer `_px3` token generation

### Akamai Bot Manager
- Sensor data collection (`akamai_pixel.js`)
- Advanced fingerprinting
- **Bypass**: Complex - consider using `agent-browser` for manual sessions, or reverse engineer the sensor data protocol

### Imperva / Incapsula
- JS-based cookie generation
- `visid_incap_` and `incap_ses_` cookies
- **Bypass**: Execute JS in browser, extract cookies, use in `requests` session

## Key Anti-Detection Checklist

1. ✅ Set realistic `User-Agent`
2. ✅ Include full browser headers (Accept, Accept-Language, Sec-Fetch-*)
3. ✅ Use `curl_cffi` to bypass TLS fingerprinting
4. ✅ Use stealth plugins (`playwright-stealth`, `undetected-chromedriver`)
5. ✅ Add random delays between requests
6. ✅ Rotate proxies for large-scale scraping
7. ✅ Persist and reuse cookies/sessions
8. ✅ Mimic human browsing patterns (scroll, move mouse, visit pages in realistic order)
9. ✅ Handle CAPTCHAs (automated or manual)
10. ✅ Monitor for blocks (403, 429, CAPTCHA pages) and adjust strategy