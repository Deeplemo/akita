#!/usr/bin/env python3
"""
Unified crawl command: detect → choose tool → fetch → extract.

Usage:
  # Auto-detect and crawl with link extraction:
  python3 crawl.py https://news.ycombinator.com

  # Extract specific elements with CSS selector:
  python3 crawl.py https://example.com --selector "h2.title a" --fields "title:text href:url"

  # Force specific mode (skip detection):
  python3 crawl.py https://example.com --mode stealth
  python3 crawl.py https://example.com --mode dynamic

  # Output formats:
  python3 crawl.py https://example.com --output json
  python3 crawl.py https://example.com --output csv
  python3 crawl.py https://example.com --output text
"""

import json
import sys
import argparse
import subprocess

SCRIPT_DIR = "/Users/lintsinghua/.agents/skills/crawler"


def detect(url):
    """Run detect.py and return parsed results."""
    result = subprocess.run(
        ["python3", f"{SCRIPT_DIR}/scripts/detect.py", url, "--json"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        return None
    stdout = result.stdout.strip()
    json_start = stdout.find("{")
    if json_start < 0:
        return None
    try:
        return json.loads(stdout[json_start:])
    except json.JSONDecodeError:
        return None


def choose_strategy(detection):
    """Based on detection results, choose the crawl strategy."""
    if not detection:
        return {
            "mode": "static",
            "fetcher": "Fetcher",
            "reason": "Detection failed, trying basic fetch",
        }

    chinese = detection.get("chinese_platform")
    if chinese and chinese.get("tool") == "MediaCrawler":
        return {
            "mode": "media_crawler",
            "fetcher": "MediaCrawler",
            "reason": f"Chinese platform detected. Use MediaCrawler.",
            "cmd": chinese.get("cmd", ""),
        }

    anti_bot = detection.get("anti_bot_detected", False)
    js_required = detection.get("js_required", False)
    auth = detection.get("auth_redirect", False)
    findings = detection.get("findings", [])
    protection = detection.get("protection_level", "none")

    if auth:
        return {
            "mode": "login",
            "fetcher": "Playwright+login",
            "reason": "Auth wall detected. Use login_session.py or MediaCrawler.",
        }

    for f in findings:
        ft = f["type"]
        if ft == "Cloudflare" and f["level"] == "high":
            return {
                "mode": "stealth",
                "fetcher": "StealthyFetcher",
                "reason": "Cloudflare JS Challenge/Turnstile",
                "solve_cf": True,
            }
        if ft == "Cloudflare":
            return {
                "mode": "stealth",
                "fetcher": "StealthyFetcher",
                "reason": "Cloudflare basic protection",
                "solve_cf": True,
            }
        if ft in ("Custom WAF/Bot Challenge",):
            return {
                "mode": "stealth",
                "fetcher": "StealthyFetcher",
                "reason": "Custom WAF challenge detected",
            }
        if ft in ("DataDome", "PerimeterX (HUMAN)"):
            return {
                "mode": "stealth",
                "fetcher": "StealthyFetcher",
                "reason": f"{ft} detected",
            }

    if js_required:
        return {
            "mode": "dynamic",
            "fetcher": "DynamicFetcher",
            "reason": "JS rendering required",
        }

    if anti_bot:
        return {
            "mode": "stealth",
            "fetcher": "StealthyFetcher",
            "reason": "Anti-bot detected, using stealth browser",
        }

    return {
        "mode": "static",
        "fetcher": "Fetcher",
        "reason": "No anti-bot, static HTML",
    }


def fetch_static(url, impersonate="chrome131"):
    """Fetch with Scrapling Fetcher (fast HTTP + TLS impersonation)."""
    from scrapling import Fetcher
    from urllib.parse import urljoin

    fetcher = Fetcher(auto_match=False)
    page = fetcher.get(url, impersonate=impersonate)
    base_url = getattr(page, "url", url) or url

    result = {
        "url": url,
        "final_url": base_url,
        "title": (page.css("title::text").get() or "").strip(),
        "mode": "static",
        "fetcher": "Fetcher",
    }

    links = []
    for a in page.css("a[href]"):
        href = a.attrib.get("href", "")
        text = (a.css("::text").get() or "").strip()
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            links.append({"text": text, "href": urljoin(base_url, href)})
    result["links"] = links
    result["link_count"] = len(links)

    all_text = page.get_all_text()
    result["text_length"] = len(all_text) if all_text else 0
    result["text_preview"] = all_text[:2000] if all_text else ""
    result["html_length"] = (
        len(page.html_content) if hasattr(page, "html_content") else 0
    )

    return result


def fetch_stealth(url, solve_cloudflare=False, headless=True, _retry=True):
    """Fetch with Scrapling StealthyFetcher (Playwright + anti-bot)."""
    from scrapling import StealthyFetcher
    from urllib.parse import urljoin
    import time

    page = StealthyFetcher.fetch(
        url, headless=headless, solve_cloudflare=solve_cloudflare
    )
    base_url = getattr(page, "url", url) or url

    all_text = page.get_all_text() or ""
    title = (page.css("title::text").get() or "").strip()

    if not all_text and not title and _retry:
        print(
            "[!] Page content empty (SPA navigating?), retrying with wait...",
            file=sys.stderr,
        )
        time.sleep(3)
        page = StealthyFetcher.fetch(
            url, headless=headless, solve_cloudflare=solve_cloudflare
        )
        base_url = getattr(page, "url", url) or url
        all_text = page.get_all_text() or ""
        title = (page.css("title::text").get() or "").strip()

    result = {
        "url": url,
        "final_url": base_url,
        "title": title,
        "mode": "stealth",
        "fetcher": "StealthyFetcher",
    }

    links = []
    for a in page.css("a[href]"):
        href = a.attrib.get("href", "")
        text = (a.css("::text").get() or "").strip()
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            links.append({"text": text, "href": urljoin(base_url, href)})
    result["links"] = links
    result["link_count"] = len(links)

    result["text_length"] = len(all_text)
    result["text_preview"] = all_text[:2000]

    return result


def fetch_dynamic(url, headless=True):
    """Fetch with Scrapling DynamicFetcher (full browser)."""
    from scrapling import DynamicFetcher
    from urllib.parse import urljoin

    fetcher = DynamicFetcher(headless=headless)
    page = fetcher.get(url)
    base_url = getattr(page, "url", url) or url

    result = {
        "url": url,
        "final_url": base_url,
        "title": (page.css("title::text").get() or "").strip(),
        "mode": "dynamic",
        "fetcher": "DynamicFetcher",
    }

    links = []
    for a in page.css("a[href]"):
        href = a.attrib.get("href", "")
        text = (a.css("::text").get() or "").strip()
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            links.append({"text": text, "href": urljoin(base_url, href)})
    result["links"] = links
    result["link_count"] = len(links)

    all_text = page.get_all_text()
    result["text_length"] = len(all_text) if all_text else 0
    result["text_preview"] = all_text[:2000] if all_text else ""

    return result


def extract_with_selector(page_result, selector, fields=None):
    """Extract specific elements from a previously fetched page.
    This requires re-fetching with Scrapling to get the page object.
    Agent should use this when they know exactly what CSS selectors to use.
    """
    from scrapling import Fetcher
    from urllib.parse import urljoin

    url = page_result["url"]
    mode = page_result.get("mode", "static")

    # Re-fetch with appropriate fetcher
    if mode == "stealth":
        from scrapling import StealthyFetcher

        page = StealthyFetcher.fetch(url, headless=True)
    elif mode == "dynamic":
        from scrapling import DynamicFetcher

        fetcher = DynamicFetcher(headless=True)
        page = fetcher.get(url)
    else:
        page = Fetcher(auto_match=False).get(url, impersonate="chrome131")

    base_url = getattr(page, "url", url) or url
    elements = page.css(selector)

    if not fields:
        # Simple extraction: just text + href for each element
        items = []
        for el in elements:
            item = {}
            item["text"] = (el.css("::text").get() or "").strip()
            href = el.attrib.get("href", "")
            if href:
                item["href"] = urljoin(base_url, href)
            items.append(item)
        return items

    # Structured extraction with field definitions
    items = []
    containers = page.css(selector)
    for container in containers:
        item = {}
        for name, config in fields.items():
            if isinstance(config, str):
                sel, attr = config, None
            else:
                sel, attr = config.get("selector"), config.get("attr")
            el = container.css(sel)
            if el:
                if attr:
                    item[name] = el.attrib.get(attr, "")
                else:
                    item[name] = (el.css("::text").get() or "").strip()
            else:
                item[name] = None
        items.append(item)
    return items


def print_report(result, strategy, detection=None, output_format="text"):
    """Print a human-readable report."""
    if output_format == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return

    print("\n" + "=" * 60)
    print("  CRAWL REPORT")
    print("=" * 60)
    print(f"  URL:            {result.get('url', 'N/A')}")
    print(f"  Final URL:      {result.get('final_url', 'N/A')}")
    print(f"  Title:          {result.get('title', 'N/A')}")
    print(
        f"  Mode:           {result.get('mode', 'N/A')} ({result.get('fetcher', 'N/A')})"
    )
    print(f"  Reason:         {strategy.get('reason', 'N/A')}")
    if result.get("link_count"):
        print(f"  Links found:    {result.get('link_count', 0)}")
    print(f"  Text length:    {result.get('text_length', 0)} chars")

    if detection:
        print(f"\n  Detection:")
        print(
            f"    Anti-bot:     {'Yes' if detection.get('anti_bot_detected') else 'No'}"
        )
        print(f"    JS Required:  {'Yes' if detection.get('js_required') else 'No'}")
        print(f"    Auth Wall:    {'Yes' if detection.get('auth_redirect') else 'No'}")
        if detection.get("chinese_platform"):
            cp = detection["chinese_platform"]
            print(f"    Chinese Site: {cp['name']} → Use {cp['tool']}")
        for f in detection.get("findings", []):
            print(f"    - {f['type']}: {f['level']}")

    if result.get("links"):
        print(f"\n  Top {min(10, len(result['links']))} links:")
        for link in result["links"][:10]:
            text = link.get("text", "")[:50]
            href = link.get("href", "")[:80]
            print(f"    {text}: {href}")

    if result.get("text_preview"):
        preview = result["text_preview"][:300]
        print(f"\n  Text preview:\n    {preview}...")

    print("=" * 60 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Unified crawl: detect → choose tool → fetch → extract",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Auto-detect and crawl:
  python3 crawl.py https://news.ycombinator.com

  # Force stealth mode:
  python3 crawl.py https://protected-site.com --mode stealth

  # Extract specific elements:
  python3 crawl.py https://example.com --selector "h2.title" --fields "title:text link:href"

  # JSON output:
  python3 crawl.py https://example.com --output json
        """,
    )
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument(
        "--mode",
        choices=["auto", "static", "stealth", "dynamic"],
        default="auto",
        help="Crawl mode (default: auto-detect)",
    )
    parser.add_argument(
        "--selector", default=None, help="CSS selector for element extraction"
    )
    parser.add_argument(
        "--fields",
        default=None,
        help="Field definitions: name:selector pairs, comma-separated",
    )
    parser.add_argument(
        "--output", choices=["text", "json"], default="text", help="Output format"
    )
    parser.add_argument("--output-file", default=None, help="Save results to file")
    parser.add_argument(
        "--solve-cloudflare", action="store_true", help="Auto-solve Cloudflare"
    )
    parser.add_argument(
        "--no-detect", action="store_true", help="Skip detection, use --mode directly"
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        default=True,
        help="Run browser headless (default)",
    )
    parser.add_argument(
        "--no-headless",
        action="store_false",
        dest="headless",
        help="Show browser window",
    )
    args = parser.parse_args()

    # Step 1: Detect (unless --no-detect or specific mode)
    detection = None
    strategy = {}

    if args.mode == "auto" and not args.no_detect:
        print(f"[1/3] Detecting anti-bot protection for {args.url}...", file=sys.stderr)
        detection = detect(args.url)
        if detection:
            strategy = choose_strategy(detection)
            print(
                f"[1/3] Detection: anti_bot={detection.get('anti_bot_detected')}, "
                f"js={detection.get('js_required')}, "
                f"auth={detection.get('auth_redirect')}",
                file=sys.stderr,
            )
            if detection.get("chinese_platform"):
                cp = detection["chinese_platform"]
                print(f"[!] Chinese platform detected: {cp['name']}", file=sys.stderr)
                print(f"[!] Recommendation: Use {cp['tool']}", file=sys.stderr)
                print(
                    f"[!] Install: {cp.get('cmd', 'pip install scrapling[all]')}",
                    file=sys.stderr,
                )
                if cp.get("tool") == "MediaCrawler":
                    print(
                        f"[!] MediaCrawler provides ready-made scrapers for Chinese platforms.",
                        file=sys.stderr,
                    )
                    print(
                        f"[!] See: references/chinese-platforms.md",
                        file=sys.stderr,
                    )
                    # Still try to crawl, but warn
        else:
            print("[1/3] Detection failed, using static fetch", file=sys.stderr)
            strategy = {
                "mode": "static",
                "fetcher": "Fetcher",
                "reason": "Detection failed",
            }
    else:
        mode = args.mode if args.mode != "auto" else "static"
        strategy = {
            "mode": mode,
            "fetcher": mode.capitalize() + "Fetcher",
            "reason": f"Forced mode: {mode}",
        }

    # Override mode from args
    mode = args.mode if args.mode != "auto" else strategy.get("mode", "static")

    # Handle Chinese platform mode — cannot auto-crawl, print recommendation and try best-effort
    if mode == "media_crawler":
        print(
            f"[!] Cannot auto-crawl this Chinese platform.",
            file=sys.stderr,
        )
        print(
            f"[!] Use MediaCrawler: git clone https://github.com/NanmiCoder/MediaCrawler.git",
        )
        print(
            f"[!] See: references/chinese-platforms.md",
            file=sys.stderr,
        )
        print(f"[!] Trying stealth fetch as best-effort fallback...", file=sys.stderr)
        mode = "stealth"

    # Step 2: Fetch
    print(f"[2/3] Fetching with {strategy.get('fetcher', mode)}...", file=sys.stderr)
    try:
        if mode == "static":
            result = fetch_static(args.url)
        elif mode == "stealth":
            solve_cf = args.solve_cloudflare or strategy.get("solve_cf", False)
            result = fetch_stealth(
                args.url, solve_cloudflare=solve_cf, headless=args.headless
            )
        elif mode == "dynamic":
            result = fetch_dynamic(args.url, headless=args.headless)
        else:
            print(f"[!] Unknown mode: {mode}. Falling back to static.", file=sys.stderr)
            result = fetch_static(args.url)
    except ImportError as e:
        print(f"[ERROR] Import failed: {e}", file=sys.stderr)
        print(f"[HINT] Install: pip install scrapling[all]", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Fetch failed: {e}", file=sys.stderr)
        sys.exit(1)

    # Step 3: Extract (use already-fetched page, not double-fetch)
    print(f"[3/3] Extracting data...", file=sys.stderr)
    if args.selector:
        try:
            items = extract_with_selector(result, args.selector)
            result["extracted"] = items
            result["extracted_count"] = len(items)
        except Exception as e:
            print(f"[WARN] Custom extraction failed: {e}", file=sys.stderr)

    # Output
    print_report(result, strategy, detection, args.output)

    if args.output_file:
        with open(args.output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"Results saved to {args.output_file}", file=sys.stderr)


if __name__ == "__main__":
    main()
