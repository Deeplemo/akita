#!/usr/bin/env python3
"""
Page probe tool — quickly discover page elements, CSS classes, and structure.
Helps you find the right CSS selectors for your crawler script.

Usage:
  # Probe a page (auto-detect fetcher):
  python3 probe.py https://example.com

  # Use stealth mode for protected sites:
  python3 probe.py https://protected-site.com --mode stealth

  # Filter by CSS selector:
  python3 probe.py https://example.com --filter "div.card"

  # Show more detail:
  python3 probe.py https://example.com --depth 2

  # JSON output:
  python3 probe.py https://example.com --output json
"""

import json
import sys
import argparse
import time
from collections import Counter


# ─── Fetching ───────────────────────────────────────────────

def fetch_static(url):
    """Fetch with Scrapling Fetcher (fast HTTP)."""
    from scrapling import Fetcher
    fetcher = Fetcher(auto_match=False)
    return fetcher.get(url, impersonate="chrome131"), "static"


def fetch_stealth(url):
    """Fetch with Scrapling StealthyFetcher."""
    from scrapling import StealthyFetcher
    return StealthyFetcher.fetch(url, headless=True, solve_cloudflare=True), "stealth"


def fetch_drissionpage(url, headless=True):
    """Fetch with DrissionPage (no WebDriver detection)."""
    from DrissionPage import ChromiumPage, ChromiumOptions

    opts = ChromiumOptions()
    if headless:
        opts.headless(True)
    opts.set_load_mode("eager")
    opts.set_argument("--disable-blink-features=AutomationControlled")
    opts.set_argument("--no-sandbox")
    opts.set_argument("--disable-gpu")

    page = ChromiumPage(opts)
    page.get(url, timeout=15)
    time.sleep(3)
    return page, "drissionpage"


# ─── Analysis ───────────────────────────────────────────────

def analyze_scrapling(page, filter_sel=None):
    """Analyze a Scrapling page object."""
    result = {
        "title": (page.css("title::text").get() or "").strip(),
        "url": getattr(page, "url", ""),
    }

    # Collect all elements with their tags and classes
    all_elements = page.css("*") if not filter_sel else page.css(filter_sel)

    tag_counter = Counter()
    class_counter = Counter()
    id_list = []
    element_details = []

    for el in all_elements:
        tag = getattr(el, "tag", None) or el.root.tag if hasattr(el, "root") else ""
        if not tag:
            continue

        tag_counter[tag] += 1

        classes = el.attrib.get("class", "")
        if classes:
            for cls in classes.split():
                class_counter[cls] += 1

        el_id = el.attrib.get("id", "")
        if el_id:
            id_list.append({"tag": tag, "id": el_id})

        # For filtered mode, show element details
        if filter_sel:
            text = (el.css("::text").get() or "").strip()[:100]
            href = el.attrib.get("href", "")
            detail = {"tag": tag, "classes": classes, "id": el_id}
            if text:
                detail["text"] = text
            if href:
                detail["href"] = href
            element_details.append(detail)

    result["tag_counts"] = dict(tag_counter.most_common(30))
    result["top_classes"] = dict(class_counter.most_common(30))
    result["ids"] = id_list[:50]
    result["filtered_elements"] = element_details[:50] if filter_sel else []

    # Links
    links = []
    for a in page.css("a[href]"):
        href = a.attrib.get("href", "")
        text = (a.css("::text").get() or "").strip()[:80]
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            links.append({"text": text, "href": href[:120]})
    result["links_count"] = len(links)
    result["links_sample"] = links[:15]

    # Text preview
    all_text = page.get_all_text()
    result["text_length"] = len(all_text) if all_text else 0
    result["text_preview"] = (all_text or "")[:500]

    return result


def analyze_drissionpage(page, filter_sel=None):
    """Analyze a DrissionPage page object."""
    result = {
        "title": page.title or "",
        "url": page.url or "",
    }

    # Close login popup if present
    for sel in [".close-circle", ".close-btn", ".modal-close"]:
        btn = page.ele(f"css:{sel}", timeout=1)
        if btn:
            btn.click()
            time.sleep(1)
            break

    # Tag and class analysis
    tag_counter = Counter()
    class_counter = Counter()
    id_list = []
    element_details = []

    # Scan all elements (limit to prevent hanging)
    targets = page.eles(f"css:{filter_sel}", timeout=3) if filter_sel else page.eles("css:*", timeout=5)

    for el in targets[:500]:  # Safety limit
        tag = el.tag or ""
        if not tag:
            continue
        tag_counter[tag] += 1

        classes = el.attr("class") or ""
        if classes:
            for cls in classes.split():
                class_counter[cls] += 1

        el_id = el.attr("id") or ""
        if el_id:
            id_list.append({"tag": tag, "id": el_id})

        if filter_sel:
            text = (el.text or "").strip()[:100]
            href = el.attr("href") or ""
            detail = {"tag": tag, "classes": classes, "id": el_id}
            if text:
                detail["text"] = text
            if href:
                detail["href"] = href[:120]
            element_details.append(detail)

    result["tag_counts"] = dict(tag_counter.most_common(30))
    result["top_classes"] = dict(class_counter.most_common(30))
    result["ids"] = id_list[:50]
    result["filtered_elements"] = element_details[:50] if filter_sel else []

    # Links
    links = []
    for a in page.eles("css:a[href]", timeout=2):
        href = a.attr("href") or ""
        text = (a.text or "").strip()[:80]
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            links.append({"text": text, "href": href[:120]})
    result["links_count"] = len(links)
    result["links_sample"] = links[:15]

    # Text preview
    body = page.ele("css:body", timeout=2)
    text = body.text if body else ""
    result["text_length"] = len(text)
    result["text_preview"] = text[:500] if text else ""

    return result


# ─── Reporting ──────────────────────────────────────────────

def print_report(result, mode):
    """Print a human-readable probe report."""
    print(f"\n{'='*60}")
    print(f"  PAGE PROBE REPORT")
    print(f"{'='*60}")
    print(f"  URL:       {result.get('url', 'N/A')}")
    print(f"  Title:     {result.get('title', 'N/A')}")
    print(f"  Fetcher:   {mode}")
    print(f"  Text len:  {result.get('text_length', 0)} chars")
    print(f"  Links:     {result.get('links_count', 0)}")

    # Top tags
    if result.get("tag_counts"):
        print(f"\n  Top Tags (first 15):")
        for tag, count in list(result["tag_counts"].items())[:15]:
            bar = "█" * min(count // 2, 40)
            print(f"    {tag:12s} {count:5d}  {bar}")

    # Top classes
    if result.get("top_classes"):
        print(f"\n  Top CSS Classes (first 20):")
        for cls, count in list(result["top_classes"].items())[:20]:
            print(f"    .{cls:35s} ×{count}")

    # IDs
    if result.get("ids"):
        print(f"\n  Element IDs (first 15):")
        for entry in result["ids"][:15]:
            print(f"    <{entry['tag']}> #{entry['id']}")

    # Filtered elements
    if result.get("filtered_elements"):
        print(f"\n  Filtered Elements ({len(result['filtered_elements'])} shown, 50 max):")
        for el in result["filtered_elements"][:20]:
            text = el.get("text", "")[:50]
            classes = el.get("classes", "")[:40]
            href = el.get("href", "")[:60]
            line = f"    <{el['tag']}>"
            if classes:
                line += f" .{classes.split()[0]}"
            if el.get("id"):
                line += f" #{el['id']}"
            if text:
                line += f" → \"{text}\""
            if href:
                line += f" [{href}]"
            print(line)

    # Links sample
    if result.get("links_sample"):
        print(f"\n  Link Sample (first 10):")
        for link in result["links_sample"][:10]:
            print(f"    {link['text'][:40]:40s} → {link['href'][:80]}")

    # Text preview
    if result.get("text_preview"):
        print(f"\n  Text Preview:")
        for line in result["text_preview"][:300].split("\n"):
            if line.strip():
                print(f"    {line.strip()[:80]}")

    print(f"{'='*60}\n")

    # Selector suggestions
    print("  💡 Suggested Selectors:")
    top_classes = list(result.get("top_classes", {}).items())[:8]
    for cls, count in top_classes:
        if count >= 2 and not cls.startswith(("css-", "style-", "v-")):
            print(f"    .{cls}  ({count} elements)")
    if result.get("ids"):
        for entry in result["ids"][:3]:
            print(f"    #{entry['id']}  (unique element)")
    print()


# ─── Main ───────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Page probe — discover elements, classes, and structure for selector building",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 probe.py https://example.com
  python3 probe.py https://protected-site.com --mode stealth
  python3 probe.py https://example.com --filter "div.card"
  python3 probe.py https://example.com --output json
        """,
    )
    parser.add_argument("url", help="URL to probe")
    parser.add_argument(
        "--mode",
        choices=["auto", "static", "stealth", "drissionpage"],
        default="auto",
        help="Fetch mode (default: auto-detect)",
    )
    parser.add_argument(
        "--filter", default=None,
        help="CSS selector to filter elements (e.g. 'div.card', 'article')",
    )
    parser.add_argument(
        "--output", choices=["text", "json"], default="text",
        help="Output format",
    )
    parser.add_argument(
        "--headless", action="store_true", default=True,
        help="Run browser headless (default)",
    )
    parser.add_argument(
        "--no-headless", action="store_false", dest="headless",
        help="Show browser window",
    )
    args = parser.parse_args()

    # Choose fetcher
    mode = args.mode
    if mode == "auto":
        # Quick heuristic: if URL looks like it needs JS, use stealth
        # Otherwise try static first
        try:
            page, mode = fetch_static(args.url)
            text_len = len(page.get_all_text() or "")
            if text_len < 200:
                # Likely needs JS — try stealth
                page, mode = fetch_stealth(args.url)
        except Exception:
            try:
                page, mode = fetch_stealth(args.url)
            except Exception:
                page, mode = fetch_drissionpage(args.url, headless=args.headless)
    elif mode == "static":
        page, mode = fetch_static(args.url)
    elif mode == "stealth":
        page, mode = fetch_stealth(args.url)
    elif mode == "drissionpage":
        page, mode = fetch_drissionpage(args.url, headless=args.headless)

    # Analyze
    if mode == "drissionpage":
        result = analyze_drissionpage(page, filter_sel=args.filter)
        page.quit()
    else:
        result = analyze_scrapling(page, filter_sel=args.filter)

    # Output
    if args.output == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_report(result, mode)


if __name__ == "__main__":
    main()
