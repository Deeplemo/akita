#!/usr/bin/env python3
"""
Website anti-bot detection script.
Probes a URL and reports the protection level, required JS rendering,
and recommended crawling strategy.

Detects: Cloudflare, DataDome, PerimeterX, Akamai, reCAPTCHA, hCaptcha,
         Turnstile, Imperva, WAF challenges (WAFJS, etc.),
         login/auth walls, custom WAF headers, and empty-page heuristics.
"""

import re
import sys
import json
import argparse
from urllib.parse import urlparse


def check_with_requests(url):
    """Try fetching with basic requests first."""
    try:
        from curl_cffi import requests as cffi_requests

        session = cffi_requests.Session(impersonate="chrome131")
        resp = session.get(url, allow_redirects=True, timeout=15)
        return {
            "backend": "curl_cffi",
            "status": resp.status_code,
            "headers": dict(resp.headers),
            "url": str(resp.url),
            "redirect_history": [str(r.url) for r in resp.history],
            "html_snippet": resp.text[:5000],
            "html_full": resp.text[:20000],
        }
    except Exception:
        pass

    try:
        import requests

        session = requests.Session()
        session.headers.update(
            {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
            }
        )
        resp = session.get(url, allow_redirects=True, timeout=15)
        return {
            "backend": "requests",
            "status": resp.status_code,
            "headers": dict(resp.headers),
            "url": str(resp.url),
            "redirect_history": [str(r.url) for r in resp.history],
            "html_snippet": resp.text[:5000],
            "html_full": resp.text[:20000],
        }
    except ImportError:
        pass

    return None


def _is_auth_redirect(original_url, final_url, redirect_history):
    """Check if the request was redirected to a login/auth page."""
    auth_keywords = [
        "/login",
        "/signin",
        "/sign-in",
        "/auth",
        "/passport",
        "/verify",
        "/challenge",
        "/i/flow/login",
        "/session/new",
        "/oauth",
        "/sso",
        "/cas/",
        "/shiro-",
        "/user/login",
    ]
    all_urls = redirect_history + [final_url]
    for u in all_urls:
        path = urlparse(u).path.lower()
        query = urlparse(u).query.lower()
        for kw in auth_keywords:
            if kw in path:
                return True
        # X/Twitter-style soft login wall: redirect_after_login in query
        if "redirect_after_login" in query or "login" in query:
            return True
    # Also check if domain changed to auth subdomain
    orig_domain = urlparse(original_url).netloc.lower()
    final_domain = urlparse(final_url).netloc.lower()
    auth_subdomains = ["passport.", "auth.", "sso.", "login.", "accounts.", "signin."]
    for prefix in auth_subdomains:
        if final_domain.startswith(prefix) and not orig_domain.startswith(prefix):
            return True
    return False


def _has_waf_challenge(html):
    """Detect custom WAF challenge scripts in HTML."""
    waf_patterns = [
        (r"waf[\-_]?challenge", "WAF challenge script"),
        (r"wafjs", "WAFJS challenge"),
        (r"out-sha256\.js", "WAF SHA-256 proof-of-work"),
        (r"__ac_", "WAF anticheat token"),
        (r"ac_nonce", "WAF nonce parameter"),
        (r"jshuid", "WAF JS fingerprint"),
        (r" navigator\.webdriver", "WebDriver detection"),
        (r" navigator\.plugins\.length", "Plugin fingerprinting"),
        (r"canvas\.toDataURL", "Canvas fingerprinting"),
        (r"webglrenderingcontext", "WebGL fingerprinting"),
        (r"audiobuffer", "Audio fingerprinting"),
    ]
    found = []
    for pattern, name in waf_patterns:
        if re.search(pattern, html, re.IGNORECASE):
            found.append(name)
    return found


def _has_empty_shell(html):
    """Check if the page is an empty shell requiring JS to render content."""
    # Very short body content
    body_start = html.find("<body")
    if body_start >= 0:
        body_end = html.find("</body>", body_start)
        if body_end >= 0:
            body_content = html[body_start:body_end]
        else:
            body_content = html[body_start:]
        # Remove all <script> tags and check remaining text
        text_only = re.sub(
            r"<script[^>]*>.*?</script>",
            "",
            body_content,
            flags=re.DOTALL | re.IGNORECASE,
        )
        text_only = re.sub(r"<[^>]+>", "", text_only).strip()
        # Remove non-alphanumeric content (spaces, newlines, CSS remnants)
        text_only_clean = re.sub(r"\s+", " ", text_only).strip()
        # If less than 200 chars of visible text after removing scripts, it's likely an empty shell
        script_count = html.count("<script")
        if len(text_only_clean) < 200 and script_count >= 1:
            return True
    # "Please wait" patterns
    wait_patterns = [
        "please wait",
        "just a moment",
        "checking your browser",
        "loading...",
        "verifying",
        "please enable javascript",
        "请等待",
        "正在验证",
        "页面加载中",
    ]
    text_lower = re.sub(r"<[^>]+>", "", html).lower().strip()
    for p in wait_patterns:
        if p in text_lower and len(text_lower) < 500:
            return True
    return False


def _detect_waf_server(headers):
    """Detect WAF/CDN from server header and other headers."""
    server = headers.get("server", "").lower()
    findings = []

    waf_servers = {
        "tencentedgeone": "EdgeOne CDN/WAF (common on Chinese sites)",
        "tencentos": "CDN (T-OS)",
        "tengine": "Tengine CDN (may include WAF)",
        "aliyunoss": "Cloud OSS",
        "yunjiasu": "Cloud CDN",
        "nginx": None,  # too generic
        "cloudflare": None,  # handled separately
    }
    for key, desc in waf_servers.items():
        if key in server and desc:
            findings.append(desc)

    # Check additional WAF headers
    for h, v in headers.items():
        hl = h.lower()
        if "x-waf" in hl or "x-websec" in hl:
            findings.append(f"WAF header detected: {h}: {v}")
        if (
            hl == "x-tencent-edge" or "tencent" in v.lower()
            if isinstance(v, str)
            else False
        ):
            findings.append("EdgeOne CDN/WAF detected")

    # Set-Cookie WAF markers
    set_cookie = headers.get("set-cookie", "").lower()
    custom_waf_cookies = {
        "_wafchallengeid": "WAF challenge cookie",
        "__ac_": "WAF anticheat cookie",
        "jsessionid": "Java session (server-rendered)",
        "_xsrf": "XSRF token (protection against CSRF)",
        "d_nsm": "Anti-bot cookie",
        "waf_uid": "WAF fingerprint cookie",
    }
    for cookie_key, desc in custom_waf_cookies.items():
        if cookie_key in set_cookie:
            findings.append(f"{desc} ({cookie_key})")

    return findings


def detect_anti_bot(result, url=""):
    """Analyze response for anti-bot indicators."""
    if not result:
        return {
            "detected": True,
            "type": "unknown",
            "level": "high",
            "note": "Could not fetch URL",
        }

    findings = []
    headers = result.get("headers", {})
    html = result.get("html_snippet", "").lower()
    html_full = result.get("html_full", html).lower()
    status = result.get("status", 0)
    final_url = result.get("url", url)
    redirect_history = result.get("redirect_history", [])

    server = headers.get("server", "").lower()
    cf_ray = headers.get("cf-ray", "")
    cf_miss = headers.get("cf-mitigated", "")

    # ------------------------------------------------------------------
    # 1. Cloudflare detection
    # ------------------------------------------------------------------
    cf_challenge = "just a moment" in html or "checking your browser" in html
    cf_turnstile_html = (
        "cf-turnstile" in html or "challenges.cloudflare.com/turnstile" in html
    )
    cf_body = "cloudflare" in html and (
        cf_challenge or cf_turnstile_html or "cf-browser-verification" in html
    )

    if cf_ray or "cloudflare" in server or cf_body:
        level = "high" if (cf_challenge or cf_miss) else "medium"
        details = "Cloudflare detected (cf-ray: {}, server: {})".format(
            "yes" if cf_ray else "no", server
        )
        if cf_challenge:
            details += " | JS Challenge detected"
        if "cf-mitigated" in headers or cf_miss:
            level = "high"
            details += " | Under attack mode"
        findings.append({"type": "Cloudflare", "level": level, "details": details})

    # ------------------------------------------------------------------
    # 2. DataDome detection
    # ------------------------------------------------------------------
    set_cookie = headers.get("set-cookie", "").lower()
    datadome_cookie = "datadome" in set_cookie
    datadome_script = "datadome" in html and ("datadome.co" in html or "ddjs" in html)
    if datadome_cookie or datadome_script:
        findings.append(
            {
                "type": "DataDome",
                "level": "high",
                "details": "DataDome bot protection detected",
            }
        )

    # ------------------------------------------------------------------
    # 3. PerimeterX / HUMAN detection
    # ------------------------------------------------------------------
    if "_px3" in html or "px-captcha" in html or "perimeterx.net" in html:
        findings.append(
            {
                "type": "PerimeterX (HUMAN)",
                "level": "high",
                "details": "PerimeterX bot protection detected",
            }
        )

    # ------------------------------------------------------------------
    # 4. Akamai Bot Manager detection
    # ------------------------------------------------------------------
    akamai_cookie = "akamai" in set_cookie
    akamai_script = "akamai_pixel" in html or "akamai.com/bot" in html
    if akamai_cookie or akamai_script:
        findings.append(
            {
                "type": "Akamai Bot Manager",
                "level": "high",
                "details": "Akamai Bot Manager detected",
            }
        )

    # ------------------------------------------------------------------
    # 5. reCAPTCHA detection
    # ------------------------------------------------------------------
    recaptcha_visible = (
        "g-recaptcha" in html
        or "grecaptcha.execute" in html
        or "google.com/recaptcha/api.js" in html
        or "recaptcha/api.js" in html
    )
    if recaptcha_visible:
        findings.append(
            {"type": "reCAPTCHA", "level": "high", "details": "reCAPTCHA detected"}
        )

    # ------------------------------------------------------------------
    # 6. hCaptcha detection
    # ------------------------------------------------------------------
    hcaptcha_visible = (
        "h-captcha" in html
        or "hcaptcha.com/1/api.js" in html
        or "data-hcaptcha-site-key" in html
        or 'class="h-captcha"' in html
    )
    if hcaptcha_visible:
        findings.append(
            {"type": "hCaptcha", "level": "high", "details": "hCaptcha detected"}
        )

    # ------------------------------------------------------------------
    # 7. Turnstile detection
    # ------------------------------------------------------------------
    if "challenges.cloudflare.com/turnstile" in html or "cf-turnstile" in html:
        findings.append(
            {
                "type": "Cloudflare Turnstile",
                "level": "high",
                "details": "Cloudflare Turnstile CAPTCHA detected",
            }
        )

    # ------------------------------------------------------------------
    # 8. Imperva / Incapsula detection
    # ------------------------------------------------------------------
    if "incapsula" in html or "visid_incap" in set_cookie:
        findings.append(
            {
                "type": "Imperva / Incapsula",
                "level": "high",
                "details": "Imperva/Incapsula protection detected",
            }
        )

    # ------------------------------------------------------------------
    # 9. Custom WAF / Bot challenge detection
    # ------------------------------------------------------------------
    waf_found = _has_waf_challenge(html_full)
    if waf_found:
        findings.append(
            {
                "type": "Custom WAF/Bot Challenge",
                "level": "high",
                "details": "Custom anti-bot detection: " + ", ".join(waf_found),
            }
        )

    # ------------------------------------------------------------------
    # 10. WAF/CDN server detection
    # ------------------------------------------------------------------
    waf_server_findings = _detect_waf_server(headers)
    for desc in waf_server_findings:
        # Known high-protection CDNs get "high" level
        level = (
            "high"
            if any(
                k in desc.lower()
                for k in ["tencent edgeone", "social commerce", "waf"]
            )
            else "medium"
        )
        findings.append({"type": "WAF/CDN", "level": level, "details": desc})

    # ------------------------------------------------------------------
    # 11. Login/auth wall detection
    # ------------------------------------------------------------------
    if _is_auth_redirect(url, final_url, redirect_history):
        findings.append(
            {
                "type": "Auth Wall",
                "level": "medium",
                "details": f"Redirected to login/auth page: {final_url}",
            }
        )

    # Also check HTML for login form indicators (even without redirect)
    auth_html_indicators = [
        ("please log in", "Login required"),
        ("please sign in", "Sign in required"),
        ("please login", "Login required"),
        ("need to login", "Login required"),
        ("sign in to continue", "Sign-in wall"),
        ("log in to view", "Login to view content"),
        ("登录", "Chinese login wall"),
        ("请先登录", "Chinese login required"),
        ("需要登录", "Chinese login required"),
        ("登录后查看", "Chinese login to view"),
        ("立即登录", "Chinese login now"),
        ("注册登录", "Chinese register/login"),
        ("登录/注册", "Chinese login/register"),
        ("马上登录", "Chinese login now"),
        ("登录后可以查看", "Chinese login to view"),
    ]
    html_text = re.sub(r"<[^>]+>", "", html).strip().lower()
    for pattern, desc in auth_html_indicators:
        if pattern in html_text:
            findings.append(
                {
                    "type": "Auth Wall",
                    "level": "medium",
                    "details": f"{desc} detected in page content",
                }
            )
            break

    # ------------------------------------------------------------------
    # 12. 403 / 429 detection
    # ------------------------------------------------------------------
    if status == 403 and not any(
        f["type"] == "Custom WAF/Bot Challenge" for f in findings
    ):
        findings.append(
            {
                "type": "Access Denied (403)",
                "level": "medium",
                "details": "Access forbidden (403) - likely bot detection",
            }
        )

    if status == 429:
        findings.append(
            {
                "type": "Rate Limiting",
                "level": "medium",
                "details": "Rate limited (429) - too many requests",
            }
        )

    # ------------------------------------------------------------------
    # JS rendering requirement detection
    # ------------------------------------------------------------------
    js_required = False

    # Empty shell heuristic
    if _has_empty_shell(html_full):
        js_required = True

    # Body minimal + scripts heuristic
    body_start = html.find("<body")
    if body_start >= 0:
        body_end = html.find("</body>", body_start)
        body_content = html[body_start:body_end] if body_end >= 0 else html[body_start:]
        text_only = re.sub(
            r"<script[^>]*>.*?</script>",
            "",
            body_content,
            flags=re.DOTALL | re.IGNORECASE,
        )
        text_only = re.sub(r"<[^>]+>", "", text_only).strip()
        script_count = html.count("<script")
        if len(text_only) < 100 and script_count >= 2:
            js_required = True

    # SPA framework markers
    js_indicators = [
        "__next",
        "__nuxt",
        "window.__INITIAL_STATE__",
        "window.__NUXT__",
        'id="__NEXT_DATA__"',
        "react-root",
        "react-dom",
        "create-react-app",
        "v-app",
        "v-cloak",
        "ng-app",
        "ng-version",
        "__vue",
        "_app-router",
        "next-route-announcer",
        "__docusaurus",
        "_bookshop_live",
        "window.__APP_DATA__",
        "window.__INITIAL_DATA__",
        "window.__DATA__",
        "window.__SSR_DATA__",
        "data-server-rendered",
    ]
    for indicator in js_indicators:
        if indicator in html or indicator in html_full:
            js_required = True
            break

    # <noscript> with meaningful content
    noscript_block = re.search(
        r"<noscript>(.*?)</noscript>", html, re.DOTALL | re.IGNORECASE
    )
    if noscript_block and len(noscript_block.group(1).strip()) > 20:
        js_required = True

    # Anti-bot challenges require JS
    challenge_types = {
        "Cloudflare",
        "Cloudflare Turnstile",
        "reCAPTCHA",
        "hCaptcha",
        "Custom WAF/Bot Challenge",
        "Auth Wall",
    }
    if any(f["type"] in challenge_types for f in findings):
        js_required = True

    # Also flag JS required for known WAF/CDN servers (these typically serve SPA content)
    waf_js_servers = ["tencentedgeone", "tengine"]
    server_lower = headers.get("server", "").lower()
    if any(s in server_lower for s in waf_js_servers):
        js_required = True

    # SPA framework detection
    spa_framework = None
    if "__next" in html or "__NEXT_DATA__" in html or "next-route-announcer" in html:
        spa_framework = "Next.js"
    elif "__nuxt" in html or "__NUXT__" in html or "_app-router" in html:
        spa_framework = "Nuxt.js"
    elif "react-root" in html or "react-dom" in html or "__react" in html:
        spa_framework = "React"
    elif "v-app" in html or "v-cloak" in html or "__vue" in html:
        spa_framework = "Vue.js"
    elif "ng-app" in html or "ng-version" in html:
        spa_framework = "Angular"

    # ------------------------------------------------------------------
    # 13. Chinese platform detection (by WAF/CDN/language heuristics)
    # ------------------------------------------------------------------
    chinese_platform = None

    # Detect Chinese platforms by combining signals:
    # - Chinese WAF/CDN server (EdgeOne, Tengine, etc.)
    # - Chinese-language content markers
    # - Chinese login patterns
    # - .cn / .com.cn domain
    has_chinese_waf = any(
        f["type"] == "WAF/CDN" and "CDN" in f.get("details", "")
        for f in findings
    )
    has_chinese_login = any(
        kw in text.lower()
        for kw in ["登录", "扫码", "验证码", "手机号"]
        for text in [html[:5000].lower()]
    )
    has_cn_domain = ".cn" in final_url or ".com.cn" in final_url

    if has_chinese_waf or has_chinese_login or has_cn_domain:
        chinese_platform = {
            "name": "Chinese platform",
            "tool": "MediaCrawler",
            "cmd": "git clone https://github.com/NanmiCoder/MediaCrawler.git",
        }

    # Determine overall protection level
    if findings:
        max_level = max(
            (f["level"] for f in findings),
            key=lambda x: ["low", "medium", "high"].index(x),
        )
    else:
        max_level = "none"

    return {
        "status": status,
        "anti_bot_detected": len(findings) > 0,
        "findings": findings,
        "max_level": max_level,
        "js_required": js_required,
        "spa_framework": spa_framework,
        "server": headers.get("server", "unknown"),
        "cf_ray": bool(cf_ray),
        "redirect_chain": redirect_history,
        "final_url": final_url,
        "auth_redirect": any(f["type"] == "Auth Wall" for f in findings),
        "chinese_platform": chinese_platform,
    }


def recommend_strategy(detection_result):
    """Recommend a crawling strategy based on detection results."""
    if not detection_result:
        return {
            "strategy": "Cannot determine - no response received",
            "tool": "N/A",
            "template": "N/A",
        }

    anti_bot = detection_result.get("anti_bot_detected", False)
    findings = detection_result.get("findings", [])
    js_required = detection_result.get("js_required", False)
    max_level = detection_result.get("max_level", "none")
    status = detection_result.get("status", 0)
    spa_framework = detection_result.get("spa_framework")
    auth_redirect = detection_result.get("auth_redirect", False)
    chinese_platform = detection_result.get("chinese_platform")

    # Chinese platform — recommend MediaCrawler directly
    if chinese_platform:
        tool = chinese_platform["tool"]
        if tool == "MediaCrawler":
            return {
                "strategy": "Chinese platform detected — use MediaCrawler",
                "tool": "MediaCrawler (recommended) or DrissionPage",
                "template": "drissionpage_crawler.py",
                "notes": "Use MediaCrawler for ready-made Chinese platform scraping. "
                f"Install: {chinese_platform['cmd']}. "
                "If MediaCrawler doesn't fit, use DrissionPage for WebDriver-free browser control.",
            }
        else:
            return {
                "strategy": "Chinese platform detected with WAF protection",
                "tool": chinese_platform["tool"],
                "template": "scrapling_crawler.py --mode stealth",
                "notes": "Chinese platform uses WAF protection. Use Scrapling StealthyFetcher with solve_cloudflare.",
            }

    # Auth wall — need login session
    if auth_redirect:
        fw = f" ({spa_framework})" if spa_framework else ""
        return {
            "strategy": f"Login/auth wall detected{fw} — content requires authentication",
            "tool": "Playwright + stealth with login flow",
            "template": "login_session.py",
            "notes": "Site requires login. Use login_session.py to authenticate first, then crawl content.",
        }

    # No anti-bot, no JS — simple static
    if not anti_bot and not js_required and status == 200:
        return {
            "strategy": "Static HTML - no anti-bot protection detected",
            "tool": "requests + BeautifulSoup or curl_cffi",
            "template": "basic_requests.py",
            "notes": "Simple HTTP requests should work fine",
        }

    # No anti-bot but JS required
    if not anti_bot and js_required:
        framework_note = f" ({spa_framework})" if spa_framework else ""
        return {
            "strategy": f"JS rendering required{framework_note}",
            "tool": "Playwright + stealth",
            "template": "playwright_stealth.py",
            "notes": "Page requires JavaScript to render content. Use Playwright stealth or intercept API calls directly.",
        }

    # Anti-bot detected
    if anti_bot:
        for f in findings:
            ftype = f["type"]

            if ftype == "Cloudflare":
                if f["level"] == "medium":
                    return {
                        "strategy": "Cloudflare basic protection",
                        "tool": "Scrapling or curl_cffi with impersonation",
                        "template": "basic_requests.py",
                        "notes": "Try curl_cffi first; use Scrapling as fallback. May need Playwright for JS challenge.",
                    }
                else:
                    return {
                        "strategy": "Cloudflare JS Challenge / Under Attack mode",
                        "tool": "Playwright + stealth or camoufox",
                        "template": "cloudflare_bypass.py",
                        "notes": "May need to wait for challenge to resolve. Use camoufox if Playwright is detected.",
                    }

            if ftype == "Cloudflare Turnstile":
                return {
                    "strategy": "Cloudflare Turnstile CAPTCHA",
                    "tool": "camoufox or agent-browser (manual)",
                    "template": "cloudflare_bypass.py",
                    "notes": "Consider using 2Captcha for automated solving",
                }

            if ftype == "Custom WAF/Bot Challenge":
                return {
                    "strategy": "Custom WAF/bot challenge detected",
                    "tool": "Playwright + stealth or camoufox",
                    "template": "playwright_stealth.py",
                    "notes": "Site uses custom bot detection (fingerprinting, PoW challenge). Use stealth browser with cookie persistence. May need session warmup.",
                }

            if ftype == "Auth Wall":
                return {
                    "strategy": "Login/auth wall — content requires authentication",
                    "tool": "Playwright + stealth with login flow",
                    "template": "login_session.py",
                    "notes": "Site requires login. Use login_session.py to authenticate first, then crawl content.",
                }

            if ftype == "DataDome":
                return {
                    "strategy": "DataDome bot protection",
                    "tool": "camoufox or undetected-chromedriver",
                    "template": "selenium_undetected.py",
                    "notes": "DataDome has advanced fingerprinting; may need session warmup",
                }

            if ftype == "PerimeterX (HUMAN)":
                return {
                    "strategy": "PerimeterX/HUMAN bot protection",
                    "tool": "camoufox or undetected-chromedriver",
                    "template": "selenium_undetected.py",
                    "notes": "PerimeterX uses behavioral analysis; mimic human behavior",
                }

            if ftype == "Akamai Bot Manager":
                return {
                    "strategy": "Akamai Bot Manager",
                    "tool": "agent-browser (manual) or Playwright with custom sensor data",
                    "template": "cloudflare_bypass.py",
                    "notes": "Akamai uses sensor data collection; very difficult to bypass automatically",
                }

            if ftype in ("reCAPTCHA", "hCaptcha"):
                return {
                    "strategy": f"{ftype} CAPTCHA protection",
                    "tool": "2Captcha API + Playwright or agent-browser (manual)",
                    "template": "cloudflare_bypass.py",
                    "notes": "Automated CAPTCHA solving requires an API service",
                }

            if ftype == "Rate Limiting":
                return {
                    "strategy": "Rate limiting detected",
                    "tool": "requests with delays + proxy rotation",
                    "template": "basic_requests.py",
                    "notes": "Add random delays (2-8s) between requests and rotate proxies",
                }

            if ftype == "WAF/CDN":
                return {
                    "strategy": "WAF/CDN detected — may have custom bot protection",
                    "tool": "Playwright + stealth (start), camoufox (escalate)",
                    "template": "playwright_stealth.py",
                    "notes": "CDN/WAF may include custom bot detection. Start with stealth browser, escalate to camoufox if blocked.",
                }

        # Fallback for any detected anti-bot
        return {
            "strategy": f"Anti-bot detected: {', '.join(f['type'] for f in findings)}",
            "tool": "Playwright + stealth (start here)",
            "template": "playwright_stealth.py",
            "notes": "Escalate to camoufox or undetected-chromedriver if blocked",
        }

    return {
        "strategy": "Unknown — manual investigation needed",
        "tool": "agent-browser for exploration",
        "template": "N/A",
        "notes": "Use agent-browser to manually inspect the page and determine anti-bot measures",
    }


def main():
    parser = argparse.ArgumentParser(
        description="Detect anti-bot protection on a website"
    )
    parser.add_argument("url", help="URL to check")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Show more details"
    )
    args = parser.parse_args()

    print(f"[INFO] Probing {args.url}...")
    result = check_with_requests(args.url)

    if not result:
        print("[ERROR] Could not fetch URL. No HTTP library available.")
        print("        Install: pip install requests curl_cffi")
        sys.exit(1)

    detection = detect_anti_bot(result, args.url)
    recommendation = recommend_strategy(detection)

    output = {
        "url": args.url,
        "final_url": detection.get("final_url", args.url),
        "status": detection.get("status", "unknown"),
        "anti_bot_detected": detection.get("anti_bot_detected", False),
        "findings": detection.get("findings", []),
        "protection_level": detection.get("max_level", "none"),
        "js_required": detection.get("js_required", False),
        "spa_framework": detection.get("spa_framework"),
        "server": detection.get("server", "unknown"),
        "cloudflare": detection.get("cf_ray", False),
        "auth_redirect": detection.get("auth_redirect", False),
        "chinese_platform": detection.get("chinese_platform"),
        "recommendation": recommendation,
    }

    if args.json:
        print(json.dumps(output, indent=2, ensure_ascii=False))
    else:
        print("\n" + "=" * 60)
        print("  ANTI-BOT DETECTION REPORT")
        print("=" * 60)
        print(f"  URL:             {output['url']}")
        print(f"  Final URL:       {output['final_url']}")
        print(f"  Status:          {output['status']}")
        print(f"  Server:          {output['server']}")
        print(f"  Cloudflare:      {'Yes' if output['cloudflare'] else 'No'}")
        print(f"  JS Required:     {'Yes' if output['js_required'] else 'No'}")
        if output["spa_framework"]:
            print(f"  SPA Framework:   {output['spa_framework']}")
        print(f"  Anti-Bot:        {'Yes' if output['anti_bot_detected'] else 'No'}")
        print(f"  Auth Required:   {'Yes' if output['auth_redirect'] else 'No'}")
        if output.get("chinese_platform"):
            cp = output["chinese_platform"]
            print(f"  Chinese Platform: {cp['name']}")
        print(f"  Protection Level:{output['protection_level']}")

        if output["findings"]:
            print("\n  Findings:")
            for f in output["findings"]:
                print(f"    - {f['type']} (level: {f['level']})")
                if args.verbose:
                    print(f"      {f['details']}")

        print("\n  RECOMMENDED STRATEGY:")
        print(f"    Strategy:  {recommendation['strategy']}")
        print(f"    Tool:      {recommendation['tool']}")
        print(f"    Template:  {recommendation['template']}")
        if recommendation.get("notes"):
            print(f"    Notes:     {recommendation['notes']}")

        print("\n  Install command:")
        if (
            "curl_cffi" in recommendation["tool"]
            or "Scrapling" in recommendation["tool"]
        ):
            print("    pip install curl_cffi scrapling")
        elif "Playwright" in recommendation["tool"]:
            print(
                "    pip install playwright playwright-stealth && python3 -m playwright install"
            )
        elif "camoufox" in recommendation["tool"]:
            print("    pip install camoufox && python3 -m camoufox fetch")
        elif "undetected" in recommendation["tool"]:
            print("    pip install undetected-chromedriver selenium")
        elif "agent-browser" in recommendation["tool"]:
            print("    npm i -g agent-browser")
        elif "requests" in recommendation["tool"]:
            print("    pip install requests beautifulsoup4 lxml")
        print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
