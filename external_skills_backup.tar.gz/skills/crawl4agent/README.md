# Crawl4Agent-skill

Advanced web crawler skill for AI agents — bypasses anti-bot protections, handles login walls, and provides robust browser automation.

## Features

- **Auto-detection**: Identifies anti-bot protections (Cloudflare, DataDome, PerimeterX, custom WAF) and selects the right bypass strategy
- **Multi-fetcher support**: Static HTTP, stealth browser, dynamic rendering — auto-chosen based on target site
- **Chinese platform support**: Ready-made integration with MediaCrawler for Chinese social platforms; DrissionPage for custom scripts
- **Login handling**: Interactive login flows (QR code, phone, OAuth) with cookie persistence
- **API interception**: Capture and replay XHR/Fetch API calls
- **Template library**: 9 battle-tested templates for common crawling patterns

## Quick Start

### 1. Auto-detect and crawl

```bash
python3 scripts/crawl.py https://example.com
```

### 2. Diagnose anti-bot protection

```bash
python3 scripts/detect.py https://example.com --verbose
```

### 3. Use a template

```python
# Static scraping (fast)
from scrapling import Fetcher
page = Fetcher(auto_match=False).get('https://example.com', impersonate='chrome131')

# Stealth scraping (bypasses anti-bot)
from scrapling import StealthyFetcher
page = StealthyFetcher.fetch('https://protected-site.com', headless=True, solve_cloudflare=True)

# DrissionPage (Chinese sites, no WebDriver detection)
from DrissionPage import ChromiumPage, ChromiumOptions
opts = ChromiumOptions()
opts.headless(True)
opts.set_load_mode("eager")  # CRITICAL: avoids hanging
page = ChromiumPage(opts)
page.get('https://example.com', timeout=15)  # CRITICAL: always set timeout
```

## Project Structure

```
├── SKILL.md                          # Skill definition and agent instructions
├── scripts/
│   ├── crawl.py                      # Auto-detect + fetch + extract
│   └── detect.py                     # Anti-bot detection
├── templates/
│   ├── scrapling_crawler.py          # General scraping (Scrapling)
│   ├── basic_requests.py             # Lightweight HTTP (curl_cffi)
│   ├── playwright_stealth.py         # JS rendering + stealth (Playwright)
│   ├── selenium_undetected.py        # DataDome/PerimeterX bypass
│   ├── cloudflare_bypass.py          # Cloudflare Turnstile/Challenge bypass
│   ├── dynamic_content.py            # Infinite scroll, lazy load
│   ├── api_interception.py           # Intercept API calls
│   ├── login_session.py              # Authenticated crawling
│   └── drissionpage_crawler.py       # Chinese sites, no WebDriver detection
└── references/
    ├── anti-detection.md             # Anti-bot techniques & bypass methods
    ├── frameworks.md                 # Framework comparison & selection guide
    ├── strategies.md                 # Strategy decision flowchart & patterns
    └── chinese-platforms.md          # Chinese platform crawling guide
```

## Key Rules

1. **Start with `crawl.py`** — it auto-detects protections and selects the right fetcher
2. **For Chinese platforms**, skip `crawl.py` and use MediaCrawler or DrissionPage directly
3. **Always set `timeout` and `load_mode("eager")`** when using DrissionPage — otherwise the browser may hang
4. **Login flows require `headless=False`** — the user must see the browser to scan QR codes or enter credentials
5. **All scripts must be tested** before delivery — unverified scripts must not be delivered

## Dependencies

| Package | Install | Purpose |
|---|---|---|
| scrapling | `pip install scrapling[all]` | Primary scraper (static/stealth/dynamic) |
| DrissionPage | `pip install DrissionPage` | Chinese sites, no WebDriver detection |
| curl_cffi | `pip install curl_cffi` | TLS fingerprint bypass |
| playwright | `pip install playwright && playwright install` | Browser automation |
| playwright-stealth | `pip install playwright-stealth` | Anti-detection for Playwright |
| undetected-chromedriver | `pip install undetected-chromedriver` | DataDome/PerimeterX bypass |

## Disclaimer

This project is intended **solely for educational and research purposes**. The tools and techniques provided are designed to help developers understand web scraping, anti-bot mechanisms, and browser automation technologies.

Users are solely responsible for ensuring that their use of this project complies with all applicable laws, regulations, and the terms of service of any website they access. The authors and contributors of this project:

- Do **not** encourage, endorse, or support any illegal or unauthorized data collection
- Do **not** guarantee that the tools will work on any specific website
- Are **not** liable for any misuse, legal violations, or damages arising from the use of this project

By using this project, you acknowledge that you are doing so at your own risk and agree to use it in a lawful and ethical manner. If you are unsure whether your intended use is permitted, consult with legal counsel before proceeding.
