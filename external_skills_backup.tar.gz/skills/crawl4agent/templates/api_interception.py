#!/usr/bin/env python3
"""
API interception crawler.
Intercepts XHR/Fetch calls to extract data directly from API endpoints.
Much faster than browser-based crawling.
"""

import json
import argparse

from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync


class APIInterceptionCrawler:
    def __init__(self, headless=True):
        self.headless = headless
        self._playwright = None
        self.browser = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        self._playwright = sync_playwright().start()
        self.browser = self._playwright.chromium.launch(
            headless=self.headless,
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
        )

    def close(self):
        if self.browser:
            self.browser.close()
        if self._playwright:
            self._playwright.stop()

    def discover_api_endpoints(
        self, url, timeout=15000, url_patterns=None, resource_types=None
    ):
        """
        Browse a page and discover all API endpoints it calls.

        url_patterns: list of strings that must be in the URL (e.g., ['/api/', '/v1/'])
        resource_types: list of resource types to capture (e.g., ['xhr', 'fetch'])
        """
        if resource_types is None:
            resource_types = ["xhr", "fetch"]
        if url_patterns is None:
            url_patterns = ["/api/", "/v1/", "/v2/", "/graphql", "/rest/"]

        context = self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )
        page = context.new_page()
        stealth_sync(page)

        api_calls = []

        def handle_request(request):
            if request.resource_type in resource_types:
                api_calls.append(
                    {
                        "method": request.method,
                        "url": request.url,
                        "headers": request.headers,
                        "post_data": request.post_data,
                        "resource_type": request.resource_type,
                    }
                )

        def handle_response(response):
            if any(p in response.url for p in url_patterns):
                try:
                    data = response.json()
                    api_calls.append(
                        {
                            "response_url": response.url,
                            "status": response.status,
                            "headers": dict(response.headers),
                            "data": data,
                        }
                    )
                except Exception:
                    api_calls.append(
                        {
                            "response_url": response.url,
                            "status": response.status,
                            "headers": dict(response.headers),
                            "data": None,
                        }
                    )

        page.on("request", handle_request)
        page.on("response", handle_response)

        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(timeout)

            # Scroll to trigger lazy loading
            for _ in range(5):
                page.evaluate("window.scrollBy(0, window.innerHeight)")
                page.wait_for_timeout(1000)

            return api_calls
        finally:
            page.close()
            context.close()

    def intercept_api(self, url, api_pattern, timeout=15000, action=None, scroll=True):
        """
        Intercept specific API calls.

        api_pattern: substring to match in URL (e.g., '/api/items')
        action: optional callable(page) to perform on the page before collecting
        scroll: whether to scroll the page to trigger lazy loading
        """
        context = self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )
        page = context.new_page()
        stealth_sync(page)

        api_data = []

        def handle_response(response):
            if api_pattern in response.url and response.status == 200:
                try:
                    data = response.json()
                    api_data.append(
                        {
                            "url": response.url,
                            "status": response.status,
                            "data": data,
                        }
                    )
                except Exception:
                    pass

        page.on("response", handle_response)

        try:
            page.goto(url, wait_until="networkidle", timeout=60000)

            if action:
                action(page)

            if scroll:
                for _ in range(10):
                    page.evaluate("window.scrollBy(0, window.innerHeight)")
                    page.wait_for_timeout(1500)

            page.wait_for_timeout(timeout)

            return api_data
        finally:
            page.close()
            context.close()

    def replay_api_call(self, api_call, use_curl_cffi=True):
        """
        Replay a captured API call using curl_cffi for TLS bypass.
        Returns the response data directly, without browser overhead.
        """
        if use_curl_cffi:
            try:
                from curl_cffi import requests

                session = requests.Session(impersonate="chrome131")
            except ImportError:
                import requests

                session = requests.Session()
        else:
            import requests

            session = requests.Session()

        headers = dict(api_call.get("headers", {}))
        headers.pop("host", None)
        headers.pop("content-length", None)

        method = api_call.get("method", "GET").upper()
        url = api_call["url"]

        if method == "GET":
            resp = session.get(url, headers=headers)
        elif method == "POST":
            resp = session.post(url, headers=headers, data=api_call.get("post_data"))
        elif method == "PUT":
            resp = session.put(url, headers=headers, data=api_call.get("post_data"))
        elif method == "DELETE":
            resp = session.delete(url, headers=headers)
        else:
            resp = session.request(method, url, headers=headers)

        try:
            return resp.json()
        except Exception:
            return resp.text

    def paginate_api(
        self,
        base_url,
        api_pattern,
        page_param="page",
        start_page=1,
        max_pages=100,
        timeout_per_page=5000,
    ):
        """
        Discover and crawl paginated API endpoints.
        """
        all_data = []

        for page_num in range(start_page, start_page + max_pages):
            url = f"{base_url}?{page_param}={page_num}"
            print(f"[INFO] Crawling page {page_num}: {url}")

            page_data = self.intercept_api(url, api_pattern, timeout=timeout_per_page)

            if not page_data:
                print(f"[INFO] No data on page {page_num}, stopping.")
                break

            all_data.extend(page_data)

        return all_data


def format_as_curl(api_call):
    """Convert an API call to a curl command for manual use."""
    method = api_call.get("method", "GET")
    url = api_call.get("url", api_call.get("response_url", ""))
    headers = api_call.get("headers", {})

    cmd = f"curl -X {method} \\\n"
    for key, value in headers.items():
        if key.lower() not in ("host", "content-length", "accept-encoding"):
            cmd += f"  -H '{key}: {value}' \\\n"

    if api_call.get("post_data"):
        cmd += f"  -d '{api_call['post_data']}' \\\n"

    cmd += f"  '{url}'"
    return cmd


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="API interception crawler")
    parser.add_argument("url", help="URL to analyze")
    parser.add_argument("--pattern", default="/api/", help="URL pattern to match")
    parser.add_argument("--output", default="api_calls.json", help="Output file")
    parser.add_argument("--timeout", type=int, default=15000, help="Wait time in ms")
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    args = parser.parse_args()

    with APIInterceptionCrawler(headless=not args.headed) as crawler:
        api_calls = crawler.discover_api_endpoints(args.url, timeout=args.timeout)

        print(f"\nDiscovered {len(api_calls)} API calls:")
        for call in api_calls:
            if "method" in call:
                print(f"  {call['method']} {call['url'][:100]}")
            elif "response_url" in call:
                print(
                    f"  Response: {call['response_url'][:100]} (status: {call['status']})"
                )

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(api_calls, f, ensure_ascii=False, indent=2, default=str)
        print(f"\nSaved to {args.output}")

        print("\n--- cURL commands for API calls ---")
        for call in api_calls[:5]:
            if "method" in call:
                print(format_as_curl(call))
                print()
