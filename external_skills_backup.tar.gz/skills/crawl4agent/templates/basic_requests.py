#!/usr/bin/env python3
"""
Basic HTTP crawler with requests, BeautifulSoup, and curl_cffi.
For static HTML pages with optional TLS fingerprint bypass.
"""

import json
import random
import time
import argparse
from urllib.parse import urljoin, urlparse

try:
    from curl_cffi import requests as cffi_requests

    HAS_CURL_CFFI = True
except ImportError:
    HAS_CURL_CFFI = False

try:
    import requests

    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from bs4 import BeautifulSoup


BROWSER_USER_AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
]

DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Cache-Control": "max-age=0",
}


class BasicCrawler:
    def __init__(self, use_curl_cffi=True, impersonate="chrome131", delay_range=(2, 5)):
        self.delay_range = delay_range
        self.results = []

        if use_curl_cffi and HAS_CURL_CFFI:
            self.session = cffi_requests.Session(impersonate=impersonate)
            self.backend = "curl_cffi"
            print(f"[INFO] Using curl_cffi with impersonation: {impersonate}")
        elif HAS_REQUESTS:
            self.session = requests.Session()
            self.session.headers.update(DEFAULT_HEADERS)
            self.session.headers["User-Agent"] = random.choice(BROWSER_USER_AGENTS)
            self.backend = "requests"
            print("[INFO] Using requests library (no TLS fingerprint bypass)")
        else:
            raise ImportError(
                "Neither requests nor curl_cffi is installed. Run: pip install requests curl_cffi"
            )

    def get(self, url, **kwargs):
        time.sleep(random.uniform(*self.delay_range))
        resp = self.session.get(url, **kwargs)
        self._check_block(resp)
        return resp

    def post(self, url, data=None, json_data=None, **kwargs):
        time.sleep(random.uniform(*self.delay_range))
        resp = self.session.post(url, data=data, json=json_data, **kwargs)
        self._check_block(resp)
        return resp

    def _check_block(self, resp):
        if resp.status_code not in (403, 429, 503):
            return
        block_indicators = {
            "cloudflare": ["cf-challenge", "just a moment", "cf-browser-verification"],
            "datadome": ["datadome", "DataDome"],
            "perimeterx": ["_px3", "perimeterx", "PerimeterX"],
            "recaptcha": ["g-recaptcha", "recaptcha/api.js"],
            "hcaptcha": ["h-captcha", "hcaptcha.com"],
        }
        text = resp.text.lower()
        for name, patterns in block_indicators.items():
            for p in patterns:
                if p.lower() in text:
                    print(
                        f"[WARN] Possible block detected: {name} (status: {resp.status_code})"
                    )
                    return

    def extract_links(self, url, selector="a[href]", base_url=None):
        resp = self.get(url)
        soup = BeautifulSoup(resp.text, "lxml")
        links = []
        for a in soup.select(selector):
            href = a.get("href", "")
            text = a.get_text(strip=True)
            if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
                full_url = urljoin(base_url or url, href)
                links.append({"text": text, "href": full_url})
        return links

    def extract_text(self, url, selector="body"):
        resp = self.get(url)
        soup = BeautifulSoup(resp.text, "lxml")
        for tag in soup(["script", "style", "nav", "footer"]):
            tag.decompose()
        elements = soup.select(selector)
        return "\n".join(el.get_text(strip=True) for el in elements)

    def extract_items(self, url, item_selector, fields):
        """
        Extract structured items from a page.

        fields: dict of {name: {'selector': 'css', 'attr': 'href'}}
                attr is optional, defaults to text content
        """
        resp = self.get(url)
        soup = BeautifulSoup(resp.text, "lxml")
        items = []

        for container in soup.select(item_selector):
            item = {}
            for name, config in fields.items():
                el = container.select_one(config["selector"])
                if el:
                    if "attr" in config:
                        item[name] = el.get(config["attr"], "").strip()
                    else:
                        item[name] = el.get_text(strip=True)
                else:
                    item[name] = None
            items.append(item)

        return items

    def crawl_paginated(
        self,
        base_url,
        item_selector,
        fields,
        page_param="page",
        start_page=1,
        max_pages=100,
        stop_condition=None,
    ):
        """
        Crawl paginated content.
        stop_condition: callable(html, page_num) -> bool, return True to stop
        """
        all_items = []
        for page_num in range(start_page, start_page + max_pages):
            url = f"{base_url}?{page_param}={page_num}"
            print(f"[INFO] Crawling page {page_num}: {url}")

            resp = self.get(url)
            soup = BeautifulSoup(resp.text, "lxml")
            items = self.extract_items(url, item_selector, fields)

            if not items:
                print(f"[INFO] No items found on page {page_num}, stopping.")
                break

            if stop_condition and stop_condition(resp.text, page_num):
                print(f"[INFO] Stop condition met on page {page_num}.")
                break

            all_items.extend(items)
            print(f"[INFO] Found {len(items)} items on page {page_num}")

        return all_items

    def save_jsonl(self, data, filepath="output.jsonl"):
        with open(filepath, "w", encoding="utf-8") as f:
            for item in data:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(f"[INFO] Saved {len(data)} items to {filepath}")

    def save_json(self, data, filepath="output.json"):
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        if isinstance(data, dict) and "links" in data:
            count = len(data["links"])
        elif isinstance(data, list):
            count = len(data)
        else:
            count = sum(len(v) for v in data.values() if isinstance(v, list))
        print(f"[INFO] Saved {count} items to {filepath}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Basic HTTP crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument(
        "--selector", default="a[href]", help="CSS selector for link extraction"
    )
    parser.add_argument("--output", default="output.json", help="Output file path")
    parser.add_argument(
        "--no-curl-cffi", action="store_true", help="Disable curl_cffi, use requests"
    )
    args = parser.parse_args()

    crawler = BasicCrawler(use_curl_cffi=not args.no_curl_cffi)
    links = crawler.extract_links(args.url, selector=args.selector)
    print(f"Found {len(links)} links")
    for link in links[:20]:
        print(f"  {link}")
    data = {"url": args.url, "links": links}
    crawler.save_json(data, args.output)
    print(f"Total: {len(links)} links saved to {args.output}")
