#!/usr/bin/env python3
"""
Distributed web crawler using Scrapy with proxy rotation and rate limiting.
For large-scale crawling projects.
"""

import json
import random
import argparse
import scrapy
from scrapy.crawler import CrawlerProcess
from scrapy.utils.project import get_project_settings
from scrapy.pipelines.files import FilesPipeline


PROXY_LIST = [
    # Add your proxies here
    # 'http://proxy1:8080',
    # 'http://proxy2:8080',
]

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
]


class RotatingProxyMiddleware:
    def process_request(self, request, spider):
        if PROXY_LIST:
            request.meta["proxy"] = random.choice(PROXY_LIST)


class RandomUserAgentMiddleware:
    def process_request(self, request, spider):
        request.headers["User-Agent"] = random.choice(USER_AGENTS)


class RetryMiddleware:
    def process_response(self, request, response, spider):
        if response.status in [403, 429, 503]:
            spider.logger.info(f"Retrying {request.url} (status: {response.status})")
            return request.copy()
        return response

    def process_exception(self, request, exception, spider):
        spider.logger.warning(f"Exception on {request.url}: {exception}")
        return request.copy()


class JsonLinesPipeline:
    def open_spider(self, spider):
        self.file = open(spider.output_file, "w", encoding="utf-8")

    def close_spider(self, spider):
        self.file.close()

    def process_item(self, item, spider):
        line = json.dumps(dict(item), ensure_ascii=False) + "\n"
        self.file.write(line)
        return item


class TemplateSpider(scrapy.Spider):
    name = "template_spider"

    # CONFIGURE THESE
    start_urls = ["https://example.com"]
    item_selector = "div.item"
    field_selectors = {
        "title": "h2.title::text",
        "url": "a.link::attr(href)",
        "description": "p.desc::text",
    }
    next_page_selector = "a.next-page::attr(href)"
    output_file = "output.jsonl"

    custom_settings = {
        "CONCURRENT_REQUESTS": 8,
        "DOWNLOAD_DELAY": random.uniform(2, 5),
        "ROBOTSTXT_OBEY": True,
        "COOKIES_ENABLED": True,
        "COOKIES_DEBUG": False,
        "DOWNLOADER_MIDDLEWARES": {
            "__main__.RotatingProxyMiddleware": 100,
            "__main__.RandomUserAgentMiddleware": 200,
            "__main__.RetryMiddleware": 300,
        },
        "ITEM_PIPELINES": {
            "__main__.JsonLinesPipeline": 100,
        },
        "AUTOTHROTTLE_ENABLED": True,
        "AUTOTHROTTLE_START_DELAY": 2,
        "AUTOTHROTTLE_MAX_DELAY": 10,
        "AUTOTHROTTLE_TARGET_CONCURRENCY": 1.0,
        "HTTPERROR_ALLOWED_CODES": [403, 429],
        "RETRY_TIMES": 3,
        "RETRY_HTTP_CODES": [403, 429, 500, 502, 503, 504],
    }

    def parse(self, response):
        for container in response.css(self.item_selector):
            item = {}
            for field, selector in self.field_selectors.items():
                item[field] = container.css(selector).get("").strip()
            yield item

        next_page = response.css(self.next_page_selector).get()
        if next_page:
            yield response.follow(next_page, callback=self.parse)


class CloudflareSpider(scrapy.Spider):
    """Spider that uses scrapy-playwright for Cloudflare-protected sites."""

    name = "cloudflare_spider"

    start_urls = ["https://example.com"]

    custom_settings = {
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
            "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
        },
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "PLAYWRIGHT_LAUNCH_OPTIONS": {
            "headless": True,
        },
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(
                url,
                meta={"playwright": True, "playwright_include_page": True},
                callback=self.parse,
            )

    async def parse(self, response):
        page = response.meta.get("playwright_page")
        if page:
            await page.close()

        for item in response.css("div.item"):
            yield {
                "title": item.css("h2::text").get(""),
                "url": item.css("a::attr(href)").get(""),
            }


def run_spider(spider_cls, output_file="output.jsonl", extra_settings=None):
    settings = {
        "USER_AGENT": random.choice(USER_AGENTS),
        "ROBOTSTXT_OBEY": True,
        "CONCURRENT_REQUESTS": 8,
        "DOWNLOAD_DELAY": 2,
        "COOKIES_ENABLED": True,
        "AUTOTHROTTLE_ENABLED": True,
        "FEEDS": {
            output_file: {
                "format": "jsonlines",
                "encoding": "utf-8",
                "overwrite": True,
            },
        },
    }
    if extra_settings:
        settings.update(extra_settings)

    process = CrawlerProcess(settings=settings)
    process.crawl(spider_cls)
    process.start()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Distributed crawler with Scrapy")
    parser.add_argument("--url", default="https://example.com", help="Start URL")
    parser.add_argument("--output", default="output.jsonl", help="Output file")
    args = parser.parse_args()

    TemplateSpider.start_urls = [args.url]
    TemplateSpider.output_file = args.output
    run_spider(TemplateSpider, args.output)
