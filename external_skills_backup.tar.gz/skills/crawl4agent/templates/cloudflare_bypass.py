#!/usr/bin/env python3
"""
Cloudflare bypass crawler.
Handles JS challenges, Turnstile CAPTCHA, and Cloudflare-protected sites.
"""

import json
import random
import time
import argparse

from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync


CF_CHALLENGE_SELECTORS = [
    "#challenge-stage",
    ".challenge-platform",
    'iframe[src*="challenges.cloudflare.com"]',
    "#cf-challenge-running",
    ".cf-browser-verification",
]


class CloudflareCrawler:
    def __init__(self, headless=True, proxy=None, turnstile_solver=None):
        self.headless = headless
        self.proxy = proxy
        self.turnstile_solver = turnstile_solver  # 'manual' or '2captcha'
        self._playwright = None
        self.browser = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        self._playwright = sync_playwright().start()
        launch_opts = {
            "headless": self.headless,
            "args": [
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--window-size=1920,1080",
            ],
        }
        if self.proxy:
            launch_opts["proxy"] = {"server": self.proxy}

        self.browser = self._playwright.chromium.launch(**launch_opts)

    def close(self):
        if self.browser:
            self.browser.close()
        if self._playwright:
            self._playwright.stop()

    def new_context(self):
        context = self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36",
            locale="en-US",
            timezone_id="America/New_York",
            geolocation={"latitude": 40.7128, "longitude": -74.0060},
        )
        return context

    def is_cloudflare_challenge(self, page):
        title = page.title().lower()
        content = page.content().lower()

        if "just a moment" in title or "attention required" in title:
            return True

        for sel in CF_CHALLENGE_SELECTORS:
            if page.query_selector(sel):
                return True

        cf_headers = ["cf-ray", "cf-cache-status", "cf-mitigated"]
        return False

    def solve_cloudflare_challenge(self, page, timeout=60000):
        """Wait for Cloudflare JS challenge to resolve."""
        start = time.time()

        while time.time() - start < timeout / 1000:
            if not self.is_cloudflare_challenge(page):
                print("[INFO] Cloudflare challenge passed!")
                return True

            try:
                challenge_btn = page.query_selector(
                    '#challenge-stage input[type="button"]'
                )
                if challenge_btn:
                    challenge_btn.click()
                    print("[INFO] Clicked challenge button")
            except Exception:
                pass

            try:
                turnstile_iframe = page.query_selector(
                    'iframe[src*="challenges.cloudflare.com"]'
                )
                if turnstile_iframe:
                    frame = turnstile_iframe.content_frame()
                    checkbox = frame.query_selector('input[type="checkbox"]')
                    if checkbox:
                        checkbox.click()
                        print("[INFO] Clicked Turnstile checkbox")
            except Exception:
                pass

            page.wait_for_timeout(3000)

        print("[WARN] Cloudflare challenge timeout")
        return False

    def crawl(self, url, wait_seconds=5, retries=3):
        """Crawl a Cloudflare-protected URL."""
        for attempt in range(retries):
            context = self.new_context()
            page = context.new_page()
            stealth_sync(page)

            try:
                page.goto(url, wait_until="domcontentloaded", timeout=60000)

                if self.is_cloudflare_challenge(page):
                    print(
                        f"[INFO] Cloudflare challenge detected (attempt {attempt + 1})"
                    )
                    self.solve_cloudflare_challenge(page)
                    page.wait_for_timeout(wait_seconds * 1000)

                content = page.content()
                cookies = context.cookies()

                return {
                    "html": content,
                    "cookies": cookies,
                    "url": page.url,
                    "title": page.title(),
                }
            except Exception as e:
                print(f"[WARN] Attempt {attempt + 1} failed: {e}")
                if attempt < retries - 1:
                    time.sleep(random.uniform(5, 15))
            finally:
                page.close()
                context.close()

        return None

    def crawl_with_session(self, urls, wait_seconds=3):
        """Crawl multiple URLs with a persistent session (reuse cookies after CF challenge)."""
        context = self.new_context()
        page = context.new_page()
        stealth_sync(page)
        results = []

        for i, url in enumerate(urls):
            print(f"[INFO] Crawling {i + 1}/{len(urls)}: {url}")

            try:
                page.goto(url, wait_until="domcontentloaded", timeout=60000)

                if self.is_cloudflare_challenge(page):
                    print("[INFO] Cloudflare challenge detected, solving...")
                    self.solve_cloudflare_challenge(page)
                    page.wait_for_timeout(wait_seconds * 1000)

                results.append(
                    {
                        "url": page.url,
                        "html": page.content(),
                        "title": page.title(),
                    }
                )
            except Exception as e:
                print(f"[WARN] Failed to crawl {url}: {e}")
                results.append({"url": url, "error": str(e)})

            time.sleep(random.uniform(2, 5))

        page.close()
        context.close()
        return results

    def extract_cookies_for_requests(self, context):
        """Extract cookies from browser context for use with requests/curl_cffi."""
        cookies = context.cookies()
        return {c["name"]: c["value"] for c in cookies}

    def get_cf_clearance(self, context):
        """Extract cf_clearance cookie for use with HTTP clients."""
        cookies = context.cookies()
        for c in cookies:
            if c["name"] == "cf_clearance":
                return c["value"]
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Cloudflare bypass crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    parser.add_argument("--retries", type=int, default=3, help="Max retries")
    args = parser.parse_args()

    with CloudflareCrawler(headless=not args.headed) as crawler:
        result = crawler.crawl(args.url, retries=args.retries)

        if result:
            print(f"Title: {result['title']}")
            print(f"URL: {result['url']}")
            print(f"Content length: {len(result['html'])} chars")
            print(f"Cookies: {len(result['cookies'])}")

            with open(args.output, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "url": result["url"],
                        "title": result["title"],
                        "html": result["html"],
                        "cookies": result["cookies"],
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )
            print(f"Saved to {args.output}")
        else:
            print("[ERROR] Failed to bypass Cloudflare")
