#!/usr/bin/env python3
"""
Dynamic content crawler for infinite scroll, lazy loading, and SPA pages.
"""

import json
import random
import time
import argparse

from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync


class DynamicContentCrawler:
    def __init__(self, headless=True, viewport_size=(1920, 1080)):
        self.headless = headless
        self.viewport_size = viewport_size
        self._playwright = None
        self.browser = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        self._playwright = sync_playwright().start()
        self.browser = self._playwright.chromium.launch(
            headless=self.headless,
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
        )

    def close(self):
        if self.browser:
            self.browser.close()
        if self._playwright:
            self._playwright.stop()

    def new_page(self):
        context = self.browser.new_context(
            viewport={"width": self.viewport_size[0], "height": self.viewport_size[1]},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )
        page = context.new_page()
        stealth_sync(page)
        return page, context

    def scroll_and_collect(
        self, url, item_selector, max_scrolls=50, scroll_delay=2000, stop_condition=None
    ):
        """
        Scroll through an infinite-scroll page and collect items.
        stop_condition: callable(page) -> bool
        """
        page, context = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(3000)

            all_items = []
            seen = set()
            no_new_count = 0

            for i in range(max_scrolls):
                elements = page.query_selector_all(item_selector)

                new_items = []
                for el in elements:
                    text = el.text_content() or ""
                    html = el.inner_html()
                    item_hash = hash(text.strip() + html[:100])

                    if item_hash not in seen:
                        seen.add(item_hash)
                        attrs = {}
                        for attr_name in ["href", "src", "data-id", "id", "class"]:
                            val = el.get_attribute(attr_name)
                            if val:
                                attrs[attr_name] = val

                        new_items.append(
                            {
                                "text": text.strip(),
                                "html": html,
                                "attributes": attrs,
                            }
                        )

                if new_items:
                    all_items.extend(new_items)
                    no_new_count = 0
                    print(
                        f"[INFO] Scroll {i + 1}: found {len(new_items)} new items (total: {len(all_items)})"
                    )
                else:
                    no_new_count += 1
                    if no_new_count >= 3:
                        print(f"[INFO] No new items for 3 scrolls, stopping.")
                        break

                page.evaluate("window.scrollBy(0, document.body.scrollHeight)")
                page.wait_for_timeout(scroll_delay + random.randint(0, 1000))

                if stop_condition and stop_condition(page):
                    break

            return all_items
        finally:
            context.close()

    def click_and_collect(
        self, url, load_more_selector, item_selector, max_clicks=50, click_delay=3000
    ):
        """
        Click "Load More" button repeatedly to load more items.
        """
        page, context = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(3000)

            all_items = []
            seen = set()

            for i in range(max_clicks):
                elements = page.query_selector_all(item_selector)

                for el in elements:
                    text = (el.text_content() or "").strip()
                    item_hash = hash(text)
                    if item_hash not in seen:
                        seen.add(item_hash)
                        all_items.append({"text": text})

                btn = page.query_selector(load_more_selector)
                if not btn:
                    print("[INFO] No more button found, stopping.")
                    break

                try:
                    btn.click()
                    page.wait_for_timeout(click_delay + random.randint(0, 1000))
                    print(f"[INFO] Click {i + 1}: total items {len(all_items)}")
                except Exception as e:
                    print(f"[WARN] Click failed: {e}")
                    break

            return all_items
        finally:
            context.close()

    def wait_for_dynamic_content(
        self, url, wait_selector, item_selector=None, timeout=30000, extra_wait=3000
    ):
        """
        Wait for dynamically loaded content to appear.
        """
        page, context = self.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)

            page.wait_for_selector(wait_selector, timeout=timeout)
            page.wait_for_timeout(extra_wait)

            if item_selector:
                elements = page.query_selector_all(item_selector)
                items = []
                for el in elements:
                    items.append(
                        {
                            "text": (el.text_content() or "").strip(),
                            "html": el.inner_html(),
                        }
                    )
                return items
            else:
                return page.content()
        finally:
            context.close()

    def intercept_and_extract(self, url, api_pattern, timeout=15000):
        """
        Intercept API calls and extract JSON data.
        Returns list of API response data.
        """
        page, context = self.new_page()
        api_data = []

        def handle_response(response):
            if api_pattern in response.url and response.status == 200:
                try:
                    data = response.json()
                    api_data.append(
                        {
                            "url": response.url,
                            "status": response.status,
                            "data": data,
                        }
                    )
                except Exception:
                    pass

        try:
            page.on("response", handle_response)
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(timeout)

            return api_data
        finally:
            context.close()

    def tab_interaction(self, url, tab_selectors, content_selector):
        """
        Click through tabs and extract content from each.
        tab_selectors: list of CSS selectors for tab buttons
        """
        page, context = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            results = []

            for i, tab_sel in enumerate(tab_selectors):
                tab = page.query_selector(tab_sel)
                if tab:
                    tab.click()
                    page.wait_for_timeout(2000)

                    content = page.query_selector(content_selector)
                    results.append(
                        {
                            "tab_index": i,
                            "content": content.text_content().strip()
                            if content
                            else None,
                        }
                    )

            return results
        finally:
            context.close()

    def lazy_load_images(
        self,
        url,
        img_selector='img[data-src], img[loading="lazy"]',
        scroll_delay=2000,
        max_scrolls=30,
    ):
        """
        Scroll to trigger lazy-loaded images and collect their src URLs.
        """
        page, context = self.new_page()
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)

            all_images = set()

            for i in range(max_scrolls):
                page.evaluate("window.scrollBy(0, window.innerHeight)")
                page.wait_for_timeout(scroll_delay)

                images = page.query_selector_all("img")
                current_count = 0
                for img in images:
                    src = (
                        img.get_attribute("src") or img.get_attribute("data-src") or ""
                    )
                    if src and src.startswith("http"):
                        if src not in all_images:
                            all_images.add(src)
                            current_count += 1

                if current_count == 0 and i > 5:
                    break

            return list(all_images)
        finally:
            context.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dynamic content crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument("--selector", default="div.item", help="Item CSS selector")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument("--mode", choices=["scroll", "click", "api"], default="scroll")
    parser.add_argument("--max-scrolls", type=int, default=50)
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    args = parser.parse_args()

    with DynamicContentCrawler(headless=not args.headed) as crawler:
        if args.mode == "scroll":
            items = crawler.scroll_and_collect(
                args.url, args.selector, max_scrolls=args.max_scrolls
            )
        elif args.mode == "api":
            items = crawler.intercept_and_extract(args.url, "/api/")
        else:
            items = []

        print(f"Found {len(items)} items")
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
        print(f"Saved to {args.output}")
