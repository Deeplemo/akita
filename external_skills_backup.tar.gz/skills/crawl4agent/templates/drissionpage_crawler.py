#!/usr/bin/env python3
"""
DrissionPage crawler — browser automation without WebDriver detection.
Best for Chinese sites that detect Selenium/Playwright.

CRITICAL: DrissionPage requires these settings to avoid hanging:
  - Always use opts.set_load_mode("eager") — default "normal" can hang on slow resources
  - Always pass timeout to page.get(url, timeout=15) — otherwise it may hang forever
  - For login flows (QR code, phone), MUST use headless=False — headless hides the UI

For ready-made Chinese platform scrapers, use MediaCrawler instead:
  git clone https://github.com/NanmiCoder/MediaCrawler.git
"""

import json
import os
import time
import random
import argparse
import sys
from pathlib import Path


def check_drissionpage():
    try:
        from DrissionPage import ChromiumPage, ChromiumOptions
        return True
    except ImportError:
        print("[ERROR] DrissionPage not installed. Run: pip install DrissionPage")
        print("        Also install Chromium if not present.")
        return False


class DrissionPageCrawler:
    def __init__(self, headless=True, user_data_dir=None, proxy=None):
        self.headless = headless
        self.user_data_dir = user_data_dir
        self.proxy = proxy
        self.page = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        from DrissionPage import ChromiumPage, ChromiumOptions

        opts = ChromiumOptions()
        if self.headless:
            opts.headless(True)
        if self.proxy:
            opts.set_proxy(self.proxy)
        if self.user_data_dir:
            opts.set_user_data_path(self.user_data_dir)

        # Anti-detection
        opts.set_argument("--disable-blink-features=AutomationControlled")
        opts.set_argument("--no-sandbox")
        opts.set_argument("--disable-infobars")
        opts.set_argument("--disable-gpu")
        opts.set_argument("--lang=zh-CN")

        # CRITICAL: eager load mode avoids hanging on slow resources
        opts.set_load_mode("eager")

        # Realistic User-Agent
        opts.set_user_agent(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        )

        self.page = ChromiumPage(opts)

    def close(self):
        if self.page:
            self.page.quit()

    def get(self, url, timeout=15, wait=3):
        """Navigate to URL. Always pass timeout to avoid hanging."""
        self.page.get(url, timeout=timeout)
        time.sleep(wait)
        return self.page

    def close_login_popup(self):
        """Close common login/auth popups that block content on Chinese sites."""
        closed = False
        # Try close button (common patterns)
        for selector in [".close-circle", ".close-btn", ".modal-close",
                         "button.close", ".popup-close"]:
            btn = self.page.ele(f"css:{selector}", timeout=1)
            if btn:
                btn.click()
                time.sleep(1)
                closed = True
                break
        # Try ESC key
        if not closed:
            try:
                self.page.actions.key_down("Escape")
                time.sleep(0.5)
            except Exception:
                pass
        return closed

    def check_logged_in(self):
        """Check if user is logged in (works for most Chinese platforms)."""
        # Login popup text indicates not logged in
        login_prompt = self.page.ele("text:马上登录即可", timeout=1)
        if login_prompt:
            return False
        # Login button in navbar suggests not logged in
        login_btn = self.page.ele("css:.login-btn", timeout=1)
        if login_btn:
            login_modal = self.page.ele("css:.login-container", timeout=1)
            if login_modal:
                return False
        return True

    def interactive_login(self, cookie_file="cookies.json"):
        """
        Open browser for user to log in manually (QR code / phone / OAuth).
        Auto-detects login success and saves cookies.

        IMPORTANT: Must be called with headless=False — headless mode hides the
        login UI (QR code, phone form) from the user.
        """
        if self.headless:
            print("[WARNING] Login requires visible browser. Use headless=False.")
            return False

        print("\n" + "=" * 55)
        print("  Please log in using the browser window:")
        print("    1. Scan QR code with mobile app")
        print("    2. Or use phone number + SMS code")
        print("  Script will auto-detect login and continue...")
        print("=" * 55)

        # Wait for user to complete login (max 3 minutes)
        for i in range(180):
            if self.check_logged_in():
                print("\n[Login] Success!")
                self.save_cookies(cookie_file)
                return True
            time.sleep(1)
            if (i + 1) % 15 == 0:
                print(f"  Waiting for login... ({i + 1}s)")

        print("[Login] Timeout, please try again")
        return False

    def save_cookies(self, cookie_file="cookies.json"):
        """Save current cookies for later reuse."""
        cookies = self.page.cookies()
        os.makedirs(os.path.dirname(os.path.abspath(cookie_file)), exist_ok=True)
        with open(cookie_file, "w", encoding="utf-8") as f:
            json.dump(cookies, f, indent=2)
        print(f"[Cookies] Saved {len(cookies)} to {cookie_file}")

    def load_cookies(self, url, cookie_file="cookies.json"):
        """Load previously saved cookies. Returns True if login is still valid."""
        if not os.path.exists(cookie_file):
            print(f"[Cookies] File not found: {cookie_file}")
            return False

        # Visit site first to set domain
        self.get(url)
        cookies = json.load(open(cookie_file, "r", encoding="utf-8"))
        loaded = 0
        for c in cookies:
            try:
                self.page.set.cookies(c)
                loaded += 1
            except Exception:
                pass

        # Refresh to apply cookies
        self.page.get(url, timeout=15)
        time.sleep(3)

        if self.check_logged_in():
            print(f"[Cookies] Loaded {loaded} cookies, login valid")
            return True
        else:
            print(f"[Cookies] Loaded {loaded} cookies, but login expired")
            return False

    def extract_text(self, url, selector="body", timeout=15, wait=3):
        self.get(url, timeout=timeout, wait=wait)
        # Close login popup if present
        self.close_login_popup()
        time.sleep(1)
        el = self.page.ele(f"css:{selector}", timeout=3)
        if el:
            return el.text
        return self.page.html

    def extract_links(self, url, selector="a"):
        self.get(url)
        self.close_login_popup()
        time.sleep(1)
        links = []
        for a in self.page.eles(f"css:{selector}"):
            href = a.attr("href") or ""
            text = a.text or ""
            if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
                links.append({"text": text.strip(), "href": href})
        return links

    def extract_items(self, url, item_selector, field_selectors):
        self.get(url)
        self.close_login_popup()
        time.sleep(1)
        return self._extract_items_from_page(self.page, item_selector, field_selectors)

    def scroll_and_collect(
        self, url, item_selector, field_selectors, max_scrolls=20,
        scroll_delay_min=2.0, scroll_delay_max=4.5,
    ):
        self.get(url)
        self.close_login_popup()
        all_items = []
        seen = set()

        for i in range(max_scrolls):
            self.page.scroll.down(500)
            time.sleep(random.uniform(scroll_delay_min, scroll_delay_max))

            items = self._extract_items_from_page(
                self.page, item_selector, field_selectors
            )
            new_items = [it for it in items if str(it) not in seen]
            for it in new_items:
                seen.add(str(it))
            all_items.extend(new_items)

            if not new_items:
                print(f"[INFO] No new items after scroll {i + 1}, stopping.")
                break

        return all_items

    def _extract_items_from_page(self, page, item_selector, field_selectors):
        items = []
        for container in page.eles(f"css:{item_selector}"):
            item = {}
            for name, config in field_selectors.items():
                if isinstance(config, str):
                    sel, attr = config, None
                else:
                    sel, attr = config.get("selector"), config.get("attr")
                el = container.ele(f"css:{sel}", timeout=1)
                if el:
                    item[name] = el.attr(attr) if attr else el.text
                else:
                    item[name] = None
            items.append(item)
        return items

    def intercept_api(self, url, api_pattern="/api/", timeout=10):
        """Listen for API requests matching a pattern."""
        api_responses = []

        def on_response(response):
            if api_pattern in response.url:
                try:
                    data = response.json()
                    api_responses.append({"url": response.url, "data": data})
                except Exception:
                    pass

        self.page.listen.add(api_pattern, on_response)
        self.get(url, timeout=15)
        time.sleep(timeout)
        return api_responses


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="DrissionPage crawler (no WebDriver)")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument("--selector", default="a", help="CSS selector for links")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument(
        "--headless", action="store_true", default=True, help="Headless mode"
    )
    parser.add_argument(
        "--no-headless", action="store_false", dest="headless",
        help="Show browser (REQUIRED for login flows)"
    )
    args = parser.parse_args()

    if not check_drissionpage():
        sys.exit(1)

    with DrissionPageCrawler(headless=args.headless) as crawler:
        links = crawler.extract_links(args.url, selector=args.selector)
        print(f"Found {len(links)} links")
        for link in links[:20]:
            print(f"  {link['text'][:50]}: {link['href'][:80]}")

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(
                {"url": args.url, "links": links, "total": len(links)},
                f,
                ensure_ascii=False,
                indent=2,
            )
        print(f"Saved {len(links)} links to {args.output}")
