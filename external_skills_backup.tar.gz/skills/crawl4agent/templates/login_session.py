#!/usr/bin/env python3
"""
Login session crawler.
Handles authenticated crawling with session persistence and cookie reuse.
"""

import json
import os
import time
import random
import argparse
from pathlib import Path

from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync


SESSION_DIR = Path.home() / ".crawler_sessions"


class LoginSessionCrawler:
    def __init__(self, headless=True, session_name="default"):
        self.headless = headless
        self.session_name = session_name
        self.session_file = SESSION_DIR / f"{session_name}.json"
        self._playwright = None
        self.browser = None
        self.context = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        self._playwright = sync_playwright().start()
        self.browser = self._playwright.chromium.launch(
            headless=self.headless,
            args=["--disable-blink-features=AutomationControlled", "--no-sandbox"],
        )

    def close(self):
        self.save_session()
        if self.context:
            self.context.close()
        if self.browser:
            self.browser.close()
        if self._playwright:
            self._playwright.stop()

    def _new_context(self):
        self.context = self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        )
        self._load_cookies()
        return self.context

    def new_page(self):
        if not self.context:
            self._new_context()
        page = self.context.new_page()
        stealth_sync(page)
        return page

    def save_session(self):
        if self.context:
            SESSION_DIR.mkdir(parents=True, exist_ok=True)
            cookies = self.context.cookies()
            with open(self.session_file, "w") as f:
                json.dump(cookies, f, indent=2)
            print(f"[INFO] Session saved to {self.session_file}")

    def _load_cookies(self):
        if self.session_file.exists():
            with open(self.session_file) as f:
                cookies = json.load(f)
            self.context.add_cookies(cookies)
            print(f"[INFO] Loaded {len(cookies)} cookies from {self.session_file}")

    def login_form(
        self,
        login_url,
        username,
        password,
        username_selector='input[name="username"], input[name="email"], input[type="email"]',
        password_selector='input[name="password"], input[type="password"]',
        submit_selector='button[type="submit"], input[type="submit"], button:has-text("Login"), button:has-text("Sign in")',
        success_indicator=None,
    ):
        """
        Login via a standard form.
        success_indicator: URL substring or page title to confirm successful login.
        """
        page = self.new_page()

        try:
            page.goto(login_url, wait_until="networkidle", timeout=60000)

            # Fill username
            username_el = page.query_selector(username_selector)
            if username_el:
                username_el.click()
                username_el.fill("")
                for char in username:
                    username_el.type(char)
                    time.sleep(random.uniform(0.03, 0.08))
            else:
                print(f"[WARN] Username field not found: {username_selector}")

            time.sleep(random.uniform(0.5, 1.5))

            # Fill password
            password_el = page.query_selector(password_selector)
            if password_el:
                password_el.click()
                password_el.fill("")
                for char in password:
                    password_el.type(char)
                    time.sleep(random.uniform(0.03, 0.08))
            else:
                print(f"[WARN] Password field not found: {password_selector}")

            time.sleep(random.uniform(0.5, 1.5))

            # Click submit
            submit_el = page.query_selector(submit_selector)
            if submit_el:
                submit_el.click()
            else:
                print(f"[WARN] Submit button not found: {submit_selector}")
                page.keyboard.press("Enter")

            # Wait for navigation
            page.wait_for_timeout(5000)

            # Check success
            if success_indicator:
                if success_indicator in page.url or success_indicator in page.title():
                    print("[INFO] Login successful!")
                else:
                    print(
                        f"[WARN] Login may have failed. URL: {page.url}, Title: {page.title()}"
                    )
            else:
                print(f"[INFO] Login form submitted. URL: {page.url}")

            return page
        except Exception as e:
            print(f"[ERROR] Login failed: {e}")
            page.close()
            raise

    def login_oauth(self, login_url, provider="google", username=None, password=None):
        """
        OAuth login helper (semi-automated).
        Opens browser for manual OAuth flow if needed.
        """
        page = self.new_page()
        page.goto(login_url, wait_until="networkidle", timeout=60000)

        # Click OAuth provider button
        oauth_selectors = {
            "google": 'button:has-text("Google"), a:has-text("Google"), [data-provider="google"]',
            "github": 'button:has-text("GitHub"), a:has-text("GitHub"), [data-provider="github"]',
            "facebook": 'button:has-text("Facebook"), a:has-text("Facebook"), [data-provider="facebook"]',
        }

        if provider in oauth_selectors:
            btn = page.query_selector(oauth_selectors[provider])
            if btn:
                btn.click()
                page.wait_for_timeout(3000)

        return page

    def extract_with_session(self, url, selector="body"):
        """Crawl a URL using the authenticated session."""
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(2000)

            # Check if redirected to login
            if "login" in page.url.lower() or "signin" in page.url.lower():
                print("[WARN] Redirected to login page. Session may have expired.")
                return None

            element = page.query_selector(selector)
            if element:
                return element.text_content()
            return page.content()
        finally:
            page.close()

    def extract_items_with_session(self, url, item_selector, field_selectors):
        """Extract structured items from an authenticated page."""
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            page.wait_for_timeout(2000)

            if "login" in page.url.lower():
                print("[WARN] Session expired, redirected to login.")
                return None

            containers = page.query_selector_all(item_selector)
            items = []

            for container in containers:
                item = {}
                for name, config in field_selectors.items():
                    if isinstance(config, str):
                        sel, attr = config, None
                    else:
                        sel, attr = config.get("selector"), config.get("attr")

                    el = container.query_selector(sel)
                    if el:
                        item[name] = (
                            el.get_attribute(attr) if attr else el.text_content()
                        )
                    else:
                        item[name] = None
                items.append(item)

            return items
        finally:
            page.close()

    def crawl_authenticated_pages(self, urls, item_selector=None, field_selectors=None):
        """Crawl multiple pages with an authenticated session."""
        all_items = []

        for i, url in enumerate(urls):
            print(f"[INFO] Crawling {i + 1}/{len(urls)}: {url}")

            if item_selector and field_selectors:
                items = self.extract_items_with_session(
                    url, item_selector, field_selectors
                )
                if items:
                    all_items.extend(items)
            else:
                content = self.extract_with_session(url)
                if content:
                    all_items.append({"url": url, "content": content})

            time.sleep(random.uniform(2, 5))

        return all_items

    def get_cookies_dict(self):
        """Get cookies as a simple dict for use with requests."""
        if self.context:
            cookies = self.context.cookies()
            return {c["name"]: c["value"] for c in cookies}
        return {}

    def export_for_requests(self):
        """Export session as a requests.Session-compatible format."""
        cookies = self.get_cookies_dict()
        session_data = {
            "cookies": cookies,
            "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            "headers": {
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
            },
        }
        return session_data


def create_requests_session_from_cookies(cookies_dict, user_agent=None):
    """Create a requests.Session from exported cookies (for fast HTTP-only crawling after login)."""
    try:
        from curl_cffi import requests

        session = requests.Session(impersonate="chrome131")
    except ImportError:
        import requests

        session = requests.Session()

    if user_agent:
        session.headers["User-Agent"] = user_agent

    for name, value in cookies_dict.items():
        session.cookies.set(name, value)

    return session


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Login session crawler")
    parser.add_argument("--url", help="Login URL")
    parser.add_argument("--username", help="Username/email")
    parser.add_argument("--password", help="Password")
    parser.add_argument("--target", help="Target URL to crawl after login")
    parser.add_argument("--selector", default="body", help="CSS selector")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument("--session", default="default", help="Session name")
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    args = parser.parse_args()

    with LoginSessionCrawler(
        headless=not args.headed, session_name=args.session
    ) as crawler:
        if args.url and args.username and args.password:
            page = crawler.login_form(args.url, args.username, args.password)

            if args.target:
                content = crawler.extract_with_session(args.target, args.selector)
                print(f"Content length: {len(content) if content else 0} chars")

                with open(args.output, "w", encoding="utf-8") as f:
                    json.dump(
                        {"url": args.target, "content": content},
                        f,
                        ensure_ascii=False,
                        indent=2,
                    )
                print(f"Saved to {args.output}")

            # Export session for reuse
            session_data = crawler.export_for_requests()
            session_file = SESSION_DIR / f"{args.session}_export.json"
            with open(session_file, "w") as f:
                json.dump(session_data, f, indent=2)
            print(f"Session data exported to {session_file}")
