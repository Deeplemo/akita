#!/usr/bin/env python3
"""
Selenium undetected-chromedriver crawler.
For sites with advanced bot detection (DataDome, PerimeterX, etc.).
"""

import json
import random
import time
import argparse

try:
    import undetected_chromedriver as uc
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC

    HAS_UC = True
except ImportError:
    HAS_UC = False

from bs4 import BeautifulSoup


class SeleniumCrawler:
    def __init__(self, headless=True, proxy=None, user_data_dir=None):
        if not HAS_UC:
            raise ImportError(
                "Install undetected-chromedriver: pip install undetected-chromedriver"
            )

        self.headless = headless
        self.proxy = proxy
        self.user_data_dir = user_data_dir
        self.driver = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        options = uc.ChromeOptions()

        if self.headless:
            options.add_argument("--headless=new")

        if self.proxy:
            options.add_argument(f"--proxy-server={self.proxy}")

        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-blink-features=AutomationControlled")

        if self.user_data_dir:
            self.driver = uc.Chrome(options=options, user_data_dir=self.user_data_dir)
        else:
            self.driver = uc.Chrome(options=options)

        self.driver.set_page_load_timeout(60)
        self.driver.implicitly_wait(10)

    def close(self):
        if self.driver:
            self.driver.quit()

    def get(self, url, wait_seconds=3):
        self.driver.get(url)
        time.sleep(wait_seconds + random.uniform(0, 2))
        return self.driver.page_source

    def extract_text(self, url, selector="body", wait_seconds=3):
        html = self.get(url, wait_seconds)
        soup = BeautifulSoup(html, "lxml")
        for tag in soup(["script", "style", "nav", "footer"]):
            tag.decompose()
        el = soup.select_one(selector)
        return el.get_text(strip=True) if el else ""

    def extract_links(self, url, selector="a[href]", wait_seconds=3):
        html = self.get(url, wait_seconds)
        soup = BeautifulSoup(html, "lxml")
        links = []
        for a in soup.select(selector):
            href = a.get("href", "")
            text = a.get_text(strip=True)
            if href and not href.startswith(("javascript:", "mailto:")):
                links.append({"text": text, "href": href})
        return links

    def extract_items(self, url, item_selector, field_selectors, wait_seconds=3):
        html = self.get(url, wait_seconds)
        soup = BeautifulSoup(html, "lxml")
        items = []

        for container in soup.select(item_selector):
            item = {}
            for name, config in field_selectors.items():
                if isinstance(config, str):
                    sel, attr = config, None
                else:
                    sel, attr = config.get("selector"), config.get("attr")

                el = container.select_one(sel)
                if el:
                    if attr:
                        item[name] = el.get(attr, "").strip()
                    else:
                        item[name] = el.get_text(strip=True)
                else:
                    item[name] = None
            items.append(item)

        return items

    def wait_for_element(self, selector, timeout=30, by=By.CSS_SELECTOR):
        return WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located((by, selector))
        )

    def click_element(self, selector, by=By.CSS_SELECTOR):
        el = self.wait_for_element(selector, by=by)
        el.click()

    def type_text(self, selector, text, by=By.CSS_SELECTOR):
        el = self.wait_for_element(selector, by=by)
        el.clear()
        for char in text:
            el.send_keys(char)
            time.sleep(random.uniform(0.03, 0.08))

    def scroll_down(self, pixels=800):
        self.driver.execute_script(f"window.scrollBy(0, {pixels})")
        time.sleep(random.uniform(0.5, 1.5))

    def infinite_scroll(self, max_scrolls=50, scroll_delay=2000, stop_condition=None):
        last_height = self.driver.execute_script("return document.body.scrollHeight")

        for i in range(max_scrolls):
            self.scroll_down()
            time.sleep(scroll_delay / 1000 + random.uniform(0, 1))

            new_height = self.driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                break
            last_height = new_height

            if stop_condition and stop_condition():
                break

    def get_cookies(self):
        return {c["name"]: c["value"] for c in self.driver.get_cookies()}

    def save_screenshot(self, filepath="screenshot.png"):
        self.driver.save_screenshot(filepath)
        return filepath

    def execute_script(self, script, *args):
        return self.driver.execute_script(script, *args)

    def switch_to_frame(self, frame_reference):
        self.driver.switch_to.frame(frame_reference)

    def switch_to_default(self):
        self.driver.switch_to.default_content()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Selenium undetected crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument("--selector", default="a[href]", help="CSS selector")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    args = parser.parse_args()

    with SeleniumCrawler(headless=not args.headed) as crawler:
        links = crawler.extract_links(args.url, selector=args.selector)
        print(f"Found {len(links)} links")
        for link in links[:20]:
            print(f"  {link['text']}: {link['href']}")

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(links, f, ensure_ascii=False, indent=2)
        print(f"Saved to {args.output}")
