#!/usr/bin/env python3
"""
Scrapling-based crawler — the go-to tool for most scraping tasks.
Replaces requests+BS4 with adaptive parsing + anti-bot bypass.
"""

import json
import argparse
import sys
from urllib.parse import urljoin


def check_scrapling():
    try:
        from scrapling import Fetcher

        return True
    except ImportError:
        print("[ERROR] Scrapling not installed. Run: pip install scrapling")
        print("        For stealth/dynamic fetchers: pip install scrapling[all]")
        return False


def crawl_static(url, impersonate="chrome131"):
    """Crawl with Fetcher (fast HTTP, TLS impersonation)."""
    from scrapling import Fetcher

    fetcher = Fetcher(auto_match=False)
    page = fetcher.get(url, impersonate=impersonate)
    return page, page.url


def crawl_stealth(url, solve_cloudflare=False, headless=True):
    """Crawl with StealthyFetcher (Playwright + anti-bot bypass)."""
    from scrapling import StealthyFetcher

    page = StealthyFetcher.fetch(
        url,
        headless=headless,
        solve_cloudflare=solve_cloudflare,
    )
    return page, url


def crawl_dynamic(url, headless=True, wait_selector=None, timeout=30):
    """Crawl with DynamicFetcher (full Playwright browser)."""
    from scrapling import DynamicFetcher

    fetcher = DynamicFetcher(headless=headless, timeout=timeout)
    if wait_selector:
        page = fetcher.get(url, wait_selector=wait_selector)
    else:
        page = fetcher.get(url)
    return page, url


def resolve_url(base_url, href):
    """Resolve relative URLs to absolute URLs."""
    if not href:
        return href
    if href.startswith(("http://", "https://", "ftp://")):
        return href
    return urljoin(base_url, href)


def extract_links(page, base_url=None):
    """Extract all links from a page, resolving relative URLs."""
    links = []
    for a in page.css("a[href]"):
        href = a.attrib.get("href", "")
        text = (a.css("::text").get() or "").strip()
        if href and not href.startswith(("javascript:", "mailto:", "#", "tel:")):
            absolute_url = resolve_url(base_url or page.url, href)
            links.append({"text": text, "href": absolute_url})
    return links


def extract_items(page, container_selector, field_selectors, base_url=None):
    """
    Extract structured items using adaptive parsing.

    field_selectors: dict of {name: css_selector} or {name: {'selector': css, 'attr': 'href'}}
    """
    items = []
    containers = page.css(container_selector)
    base = base_url or getattr(page, "url", "")

    for container in containers:
        item = {}
        for name, config in field_selectors.items():
            if isinstance(config, str):
                sel, attr = config, None
            else:
                sel, attr = config.get("selector"), config.get("attr")

            element = container.css(sel)
            if element:
                if attr:
                    val = element.attrib.get(attr, "")
                    item[name] = resolve_url(base, val) if attr == "href" else val
                else:
                    item[name] = (element.css("::text").get() or "").strip()
            else:
                matching = container.find_by_text(name, first_match=True)
                if matching:
                    item[name] = (matching.css("::text").get() or "").strip()
                else:
                    item[name] = None
        items.append(item)

    return items


def infinite_scroll(
    url, container_selector, field_selectors, max_scrolls=20, scroll_delay=2000
):
    """Scroll and collect items from an infinite-scroll page."""
    from scrapling import DynamicFetcher

    fetcher = DynamicFetcher(headless=True)
    all_items = []
    seen_texts = set()

    for i in range(max_scrolls):
        try:
            page = fetcher.get(url)
            items = extract_items(
                page, container_selector, field_selectors, base_url=url
            )
            new_items = [it for it in items if it.get("title", "") not in seen_texts]
            for it in new_items:
                seen_texts.add(it.get("title", ""))
            all_items.extend(new_items)
            if not new_items:
                break
        except Exception as e:
            print(f"[WARN] Scroll {i} failed: {e}")
            break

    return all_items


def crawl_with_detection(url):
    """Auto-detect the best crawl method using detect.py results."""
    import subprocess

    result = subprocess.run(
        [
            "python3",
            "/Users/lintsinghua/.agents/skills/crawler/scripts/detect.py",
            url,
            "--json",
        ],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        print("[WARN] Detection failed, falling back to Fetcher")
        return crawl_static(url)

    # Strip any non-JSON lines (e.g., [INFO] prefix)
    stdout = result.stdout.strip()
    json_start = stdout.find("{")
    if json_start >= 0:
        stdout = stdout[json_start:]

    try:
        detection = json.loads(stdout)
    except json.JSONDecodeError:
        print("[WARN] Detection output invalid, falling back to Fetcher")
        return crawl_static(url)

    anti_bot = detection.get("anti_bot_detected", False)
    js_required = detection.get("js_required", False)
    findings = detection.get("findings", [])

    print(f"[INFO] Detection: anti_bot={anti_bot}, js_required={js_required}")
    for f in findings:
        print(f"  - {f['type']} (level: {f['level']})")

    if not anti_bot and not js_required:
        print("[INFO] Using Fetcher (static HTTP)")
        return crawl_static(url)

    for f in findings:
        ftype = f["type"]
        if ftype == "Cloudflare" and f["level"] == "high":
            print("[INFO] Using StealthyFetcher (Cloudflare bypass)")
            return crawl_stealth(url, solve_cloudflare=True)
        if ftype == "Cloudflare":
            print("[INFO] Using StealthyFetcher (Cloudflare basic)")
            return crawl_stealth(url)
        if ftype in ("Custom WAF/Bot Challenge", "DataDome", "PerimeterX (HUMAN)"):
            print("[INFO] Using StealthyFetcher (WAF bypass)")
            return crawl_stealth(url)
        if ftype == "Auth Wall":
            print("[INFO] Auth wall detected — using StealthyFetcher with login flow")
            print(
                "[INFO] Consider using login_session.py template for authenticated crawling"
            )
            return crawl_stealth(url)

    if js_required:
        print("[INFO] Using DynamicFetcher (JS rendering)")
        return crawl_dynamic(url)

    print("[INFO] Using Fetcher (default)")
    return crawl_static(url)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scrapling-based crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument(
        "--mode",
        choices=["auto", "static", "stealth", "dynamic"],
        default="auto",
        help="Crawl mode",
    )
    parser.add_argument(
        "--selector", default="a[href]", help="CSS selector for link extraction"
    )
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument(
        "--solve-cloudflare", action="store_true", help="Auto-solve Cloudflare"
    )
    parser.add_argument(
        "--headless", action="store_true", default=True, help="Headless mode"
    )
    parser.add_argument(
        "--no-headless", action="store_false", dest="headless", help="Show browser"
    )
    args = parser.parse_args()

    if not check_scrapling():
        sys.exit(1)

    if args.mode == "auto":
        page, base_url = crawl_with_detection(args.url)
    elif args.mode == "static":
        page, base_url = crawl_static(args.url)
    elif args.mode == "stealth":
        page, base_url = crawl_stealth(
            args.url, solve_cloudflare=args.solve_cloudflare, headless=args.headless
        )
    elif args.mode == "dynamic":
        page, base_url = crawl_dynamic(args.url, headless=args.headless)
    else:
        page, base_url = crawl_static(args.url)

    if args.selector and args.selector != "a[href]":
        elements = page.css(args.selector)
        items = []
        for el in elements:
            text = (el.css("::text").get() or "").strip()
            href = el.attrib.get("href", "")
            if href:
                href = resolve_url(base_url, href)
            items.append({"text": text, "href": href} if href else {"text": text})
        print(f"Found {len(items)} elements matching '{args.selector}'")
        for item in items[:20]:
            print(f"  {str(item)[:80]}")

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(
                {"url": args.url, "elements": items, "total": len(items)},
                f,
                ensure_ascii=False,
                indent=2,
            )
        print(f"Saved {len(items)} elements to {args.output}")
    else:
        links = extract_links(page, base_url=base_url)
        print(f"Found {len(links)} links")
        for link in links[:20]:
            print(f"  {link['text'][:50]}: {link['href'][:80]}")

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(
                {"url": args.url, "links": links, "total": len(links)},
                f,
                ensure_ascii=False,
                indent=2,
            )
        print(f"Saved {len(links)} links to {args.output}")
