#!/usr/bin/env python3
"""
Playwright crawler with stealth mode.
For JavaScript-rendered pages and Cloudflare JS challenges.
"""

import json
import random
import time
import argparse

from playwright.sync_api import sync_playwright
from playwright_stealth import stealth_sync


BROWSER_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-dev-shm-usage",
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-infobars",
    "--window-size=1920,1080",
]


class PlaywrightCrawler:
    def __init__(self, headless=True, proxy=None, user_data_dir=None):
        self.headless = headless
        self.proxy = proxy
        self.user_data_dir = user_data_dir
        self.browser = None
        self.context = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *args):
        self.close()

    def start(self):
        self._playwright = sync_playwright().start()
        launch_opts = {"headless": self.headless, "args": BROWSER_ARGS}

        if self.proxy:
            launch_opts["proxy"] = {"server": self.proxy}

        if self.user_data_dir:
            self.context = self._playwright.chromium.launch_persistent_context(
                self.user_data_dir, **launch_opts
            )
            self.browser = self.context.browser
        else:
            self.browser = self._playwright.chromium.launch(**launch_opts)
            self.context = self.browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            )

    def close(self):
        if self.context:
            self.context.close()
        if self.browser:
            self.browser.close()
        self._playwright.stop()

    def new_page(self):
        page = self.context.new_page()
        stealth_sync(page)
        return page

    def goto(self, url, page=None, wait_until="networkidle", timeout=60000):
        if page is None:
            page = self.new_page()
        page.goto(url, wait_until=wait_until, timeout=timeout)
        return page

    def wait_for_cloudflare(self, page, timeout=30000):
        for _ in range(timeout // 1000):
            title = page.title()
            if (
                "just a moment" not in title.lower()
                and "cloudflare" not in title.lower()
            ):
                return True
            page.wait_for_timeout(1000)
        return False

    def extract_text(self, url, selector="body"):
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            self.wait_for_cloudflare(page)
            page.wait_for_timeout(2000)
            element = page.query_selector(selector)
            if element:
                return element.text_content()
            return page.content()
        finally:
            page.close()

    def extract_links(self, url, selector="a[href]"):
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            self.wait_for_cloudflare(page)
            elements = page.query_selector_all(selector)
            links = []
            for el in elements:
                href = el.get_attribute("href")
                text = el.text_content()
                if href:
                    links.append({"text": text.strip() if text else "", "href": href})
            return links
        finally:
            page.close()

    def extract_items(self, url, item_selector, field_selectors):
        """
        Extract structured items.
        field_selectors: dict of {field_name: css_selector} or
                         {field_name: {'selector': 'css', 'attr': 'href'}}
        """
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            self.wait_for_cloudflare(page)
            page.wait_for_timeout(2000)

            containers = page.query_selector_all(item_selector)
            items = []

            for container in containers:
                item = {}
                for name, config in field_selectors.items():
                    if isinstance(config, str):
                        sel, attr = config, None
                    else:
                        sel, attr = config.get("selector"), config.get("attr")

                    el = container.query_selector(sel)
                    if el:
                        if attr:
                            item[name] = el.get_attribute(attr) or ""
                        else:
                            item[name] = el.text_content() or ""
                    else:
                        item[name] = None
                items.append(item)

            return items
        finally:
            page.close()

    def intercept_api(self, url, api_pattern="/api/", timeout=10000):
        """
        Intercept API calls made by the page.
        Returns list of (url, response_data) tuples.
        """
        page = self.new_page()
        api_responses = []

        def handle_response(response):
            if api_pattern in response.url and response.status == 200:
                try:
                    data = response.json()
                    api_responses.append({"url": response.url, "data": data})
                except Exception:
                    pass

        page.on("response", handle_response)
        page.goto(url, wait_until="networkidle", timeout=60000)
        page.wait_for_timeout(timeout)
        page.close()
        return api_responses

    def scroll_and_collect(
        self, url, item_selector, max_scrolls=50, scroll_delay=2000, stop_at_count=None
    ):
        """
        Scroll through an infinite-scroll page and collect items.
        """
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            self.wait_for_cloudflare(page)

            all_items = []
            seen_texts = set()

            for i in range(max_scrolls):
                elements = page.query_selector_all(item_selector)

                for el in elements:
                    text = el.text_content()
                    if text and text not in seen_texts:
                        seen_texts.add(text)
                        all_items.append(
                            {
                                "text": text.strip(),
                                "html": el.inner_html(),
                            }
                        )

                if stop_at_count and len(all_items) >= stop_at_count:
                    break

                page.evaluate("window.scrollBy(0, document.body.scrollHeight)")
                page.wait_for_timeout(scroll_delay + random.randint(0, 1000))

                new_elements = page.query_selector_all(item_selector)
                if len(new_elements) == len(elements) and i > 5:
                    break

            return all_items
        finally:
            page.close()

    def screenshot(self, url, filepath="screenshot.png", full_page=False):
        page = self.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60000)
            self.wait_for_cloudflare(page)
            page.screenshot(path=filepath, full_page=full_page)
            return filepath
        finally:
            page.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Playwright stealth crawler")
    parser.add_argument("url", help="URL to crawl")
    parser.add_argument("--selector", default="a[href]", help="CSS selector")
    parser.add_argument("--output", default="output.json", help="Output file")
    parser.add_argument("--headed", action="store_true", help="Run in headed mode")
    args = parser.parse_args()

    with PlaywrightCrawler(headless=not args.headed) as crawler:
        links = crawler.extract_links(args.url, selector=args.selector)
        print(f"Found {len(links)} links")
        for link in links[:20]:
            print(f"  {link['text']}: {link['href']}")

        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(links, f, ensure_ascii=False, indent=2)
        print(f"Saved to {args.output}")
