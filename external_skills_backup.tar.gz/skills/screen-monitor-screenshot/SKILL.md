---
name: screen-monitor-screenshot
description: Use when the user asks to capture, send, monitor, inspect, or compare the current Ubuntu GNOME Wayland desktop screen.
---

# Screen Monitor Screenshot

## Overview

Use `screen-monitor` MCP for desktop screenshots and monitoring. In this user's Ubuntu GNOME Wayland VM, the verified reliable backend is:

```bash
gnome-screenshot -f <target-path>
```

`grim`, GNOME Shell D-Bus screenshot, X11 fallback screenshots, and silent portal screenshots were unreliable or blocked in this environment.

## When to Use

Use this skill when the user asks:

- “截图”, “全屏截图”, “截桌面图”, “发我当前屏幕”
- “监控屏幕”, “看看桌面”, “屏幕有没有变化”
- Any task requiring current desktop visual state, not browser-page-only screenshots

Do not use this for browser page screenshots; use browser tools or Chrome DevTools for webpage-only captures.

## Required Backend Choice

Preferred path:

1. `screen-monitor` MCP `diagnose` once per task when state is unknown.
2. `screen-monitor` MCP `capture_screen` for a one-shot desktop screenshot.
3. `deliver_artifacts` to send the returned PNG to the current chat.

The MCP server is expected to use `gnome-screenshot` internally. If the backend is missing, install it:

```bash
sudo apt update
sudo apt install -y gnome-screenshot
```

## Quick Reference

| Need | Use |
|---|---|
| Capture desktop once | `call_mcp_tool(server="screen-monitor", tool_name="capture_screen", arguments={})` |
| Check backend | `call_mcp_tool(server="screen-monitor", tool_name="diagnose", arguments={})` |
| Compare current screen with previous | `monitor_once` |
| List past captures | `list_recent_captures` |
| Send screenshot in IM | `deliver_artifacts` with type `image` |

## Environment Lessons

- GNOME Wayland blocks silent background screenshots by design.
- `gnome-screenshot -f <path>` has been verified on this machine to produce valid `1920x1080` non-black PNG screenshots.
- `grim` fails on GNOME/Mutter because it requires wlroots `wlr-screencopy`.
- GNOME Shell D-Bus may return `Screenshot is not allowed`.
- xdg-desktop-portal may require interactive consent and previously crashed in this session.
- X11/PIL/mss fallbacks can produce black or invalid screenshots under Wayland/Xwayland.

## Common Mistakes

- Do not use removed legacy skills `wayland-screenshot` or `wayland-screenshot-daemon`.
- Do not claim success until the MCP returns a successful capture path and the file exists.
- Do not send black/empty fallback images as valid screenshots.
- Do not ask for portal permission first when `screen-monitor` MCP is available.
