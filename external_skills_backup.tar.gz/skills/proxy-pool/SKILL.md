# Proxy Pool Skill

自主代理池管理系统。自动从各大免费代理网站爬取 HTTP/HTTPS/SOCKS4/SOCKS5 代理，验证可用性，定时更新，自动清理过期代理，对外提供 API。

## 核心能力

1. **自动爬取代理** — 从多个源（ihuan、kuaidaili、github 代理列表等）并发爬取
2. **多协议支持** — HTTP、HTTPS、SOCKS4、SOCKS5
3. **自动验证** — 验证代理可用性、匿名性、延迟
4. **定时更新** — 可配置间隔自动爬取新代理
5. **自动清理** — 淘汰过期/失效代理，保持池子健康
6. **API 接口** — 提供标准化 API 供其他脚本获取代理
7. **自动使用** — 其他 skill 需要时自动从池中提供代理

## 架构

```
proxypool/
├── __init__.py
├── runner.py         # 一键启动
├── config.py         # 配置
├── fetchers/         # 代理爬取
│   ├── base.py
│   ├── github_list.py
│   ├── proxyscrape.py
│   └── custom_sources.py
├── checker.py        # 代理验证
├── storage.py        # 代理存储（JSON文件）
├── scheduler.py      # 定时调度
├── api.py            # 对外 API
├── data/
│   ├── proxies.json  # 当前有效代理
│   └── stats.json    # 统计信息
└── logs/
```

## 使用方式

### 1. 单次爬取 + 验证

```bash
python3 scripts/runner.py --once
```

### 2. 定时模式（后台持续运行）

```bash
python3 scripts/runner.py --daemon --interval 600
```

### 3. 从代理池获取代理

```python
from proxy_pool import get_proxy

# 获取一个 HTTP 代理
proxy = get_proxy(protocol='http')

# 获取一个 SOCKS5 代理
proxy = get_proxy(protocol='socks5')

# 获取任意协议可用代理
proxy = get_proxy()
```

### 4. 查询代理池状态

```bash
python3 scripts/runner.py --stats
```

## 代理源

默认从以下源爬取免费代理（中国大陆可用）：

- GitHub 代理列表仓库
- proxyscrape API
- 免费代理网站（自动适配）
- 自定义静态源

## 验证策略

- 并发验证（默认 50 并发）
- HTTP 代理：请求 httpbin.org/ip 验证
- SOCKS 代理：通过 SOCKS 连接验证
- 验证超时：5 秒
- 自动淘汰连续失败 3 次的代理
- 保留延迟 < 2s 的高质量代理

## 自动使用规则

当其他 skill 或脚本需要代理时：

1. 检查 `data/proxies.json` 是否有可用代理
2. 如果代理池为空或全部过期，自动触发一次爬取
3. 如果有可用代理，直接返回最优代理
4. 代理失败时自动切换下一个并标记失效

## 定时维护

- 默认每 600 秒（10 分钟）自动爬取 + 验证
- 代理有效期（TTL）默认 1800 秒（30 分钟）
- 过期代理自动清理
- 保持最少 20 个可用代理