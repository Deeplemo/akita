"""代理池配置文件"""
import os

# 数据目录
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
PROXIES_FILE = os.path.join(DATA_DIR, 'proxies.json')
STATS_FILE = os.path.join(DATA_DIR, 'stats.json')
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'logs')

# 验证配置
CHECK_TIMEOUT = 5           # 代理验证超时（秒）
CHECK_CONCURRENCY = 50       # 并发验证数
MAX_FAIL_COUNT = 3           # 最大连续失败次数，超过则淘汰
MAX_PROXIES = 500            # 代理池最大容量
MIN_PROXIES = 20             # 最少保留代理数

# 代理质量过滤
MAX_LATENCY = 2.0            # 最大允许延迟（秒）
MIN_QUALITY_SCORE = 0.3      # 最低质量分数

# TTL 配置（秒）
PROXY_TTL = 1800             # 代理有效期 30 分钟
CRAWL_INTERVAL = 600         # 爬取间隔 10 分钟
CLEAN_INTERVAL = 900         # 清理间隔 15 分钟

# ===== 代理源列表（中国大陆可访问的免费源）=====
PROXY_SOURCES = [
    # proxyscrape — 高可用，支持多协议
    "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&protocol=http&proxy_format=protocolipport&format=json&timeout=20000",
    "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&protocol=socks4&proxy_format=protocolipport&format=json&timeout=20000",
    "https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&protocol=socks5&proxy_format=protocolipport&format=json&timeout=20000",

    # proxylist.geonode — 多协议 API
    # "https://proxylist.geonode.com/api/proxy-list?limit=100&page=1&sort_by=lastChecked&sort_type=desc&protocols=http,https,socks4,socks5",

    # 免费代理文本列表（GitHub raw）
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks4.txt",
    "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt",

    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt",
    "https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt",

    "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt",

    # openproxy.space — JSON API
    "https://api.openproxylist.xyz/http.txt",
    "https://api.openproxylist.xyz/socks4.txt",
    "https://api.openproxylist.xyz/socks5.txt",

    # proxy-list.download — 批量代理
    "https://www.proxy-list.download/api/v1/get?type=http",
    "https://www.proxy-list.download/api/v1/get?type=https",
    "https://www.proxy-list.download/api/v1/get?type=socks4",
    "https://www.proxy-list.download/api/v1/get?type=socks5",
]

# 中国特供备用源（需要额外处理）
CN_PROXY_SOURCES = [
    # 可进一步添加 kuaidaili、ihuan 等
]

# 验证目标 URL
CHECK_URLS = {
    'http': 'http://httpbin.org/ip',
    'https': 'https://httpbin.org/ip',
    'socks4': 'http://httpbin.org/ip',
    'socks5': 'http://httpbin.org/ip',
}

# 备用验证 URL（当主 URL 不可用）
FALLBACK_CHECK_URLS = [
    'http://ip-api.com/json',
    'http://ifconfig.me/ip',
]