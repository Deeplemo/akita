"""代理爬取模块 — 从多个源并发爬取 HTTP/SOCKS 代理"""
import asyncio
import re
import json
import logging
from urllib.parse import urlparse

logger = logging.getLogger("proxy_pool.fetchers")


async def fetch_text(url, session, timeout=15):
    """抓取文本内容"""
    try:
        async with session.get(url, timeout=timeout) as resp:
            if resp.status == 200:
                return await resp.text()
    except Exception as e:
        logger.debug(f"fetch failed: {url} — {e}")
    return None


async def fetch_json(url, session, timeout=15):
    """抓取 JSON"""
    try:
        async with session.get(url, timeout=timeout) as resp:
            if resp.status == 200:
                return await resp.json()
    except Exception as e:
        logger.debug(f"fetch json failed: {url} — {e}")
    return None


def parse_ip_port(text, default_protocol='http'):
    """从文本中提取 ip:port，自动判断协议"""
    proxies = set()
    # 匹配格式: protocol://ip:port 或 ip:port
    patterns = [
        r'(?:https?|socks[45])://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5}',
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5}',
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for m in matches:
            m = m.strip()
            protocol = default_protocol
            if '://' in m:
                protocol_part = m.split('://')[0].lower()
                if protocol_part in ('http', 'https', 'socks4', 'socks5'):
                    protocol = protocol_part
                m = m.split('://')[1]
            proxies.add((protocol, m))
    return list(proxies)


def parse_proxyscrape_json(data, default_protocol='http'):
    """解析 proxyscrape JSON 格式"""
    proxies = set()
    if isinstance(data, dict) and 'proxies' in data:
        for item in data['proxies']:
            proto = item.get('protocol', default_protocol).lower()
            ip = item.get('ip', '')
            port = item.get('port', '')
            if ip and port:
                proxies.add((proto, f"{ip}:{port}"))
    return list(proxies)


async def fetch_from_github_lists(session):
    """从 GitHub raw 文本列表爬取"""
    from config import PROXY_SOURCES

    proxies = set()
    text_urls = [u for u in PROXY_SOURCES if 'raw.githubusercontent.com' in u
                 or 'openproxylist' in u or 'proxy-list.download' in u]

    tasks = [fetch_text(url, session) for url in text_urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for url, text in zip(text_urls, results):
        if isinstance(text, str) and text:
            p = parse_ip_port(text)
            proxies.update(p)
            logger.debug(f"  {url}: got {len(p)} proxies")

    return list(proxies)


async def fetch_from_proxyscrape(session):
    """从 proxyscrape API 爬取 JSON"""
    from config import PROXY_SOURCES

    proxies = set()
    json_urls = [u for u in PROXY_SOURCES if 'api.proxyscrape.com' in u]

    tasks = [fetch_json(url, session) for url in json_urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for url, data in zip(json_urls, results):
        if isinstance(data, (dict, list)):
            p = parse_proxyscrape_json(data)
            proxies.update(p)
            logger.debug(f"  {url}: got {len(p)} proxies")

    return list(proxies)


async def fetch_from_proxy_list_download(session):
    """从 proxy-list.download API 爬取"""
    from config import PROXY_SOURCES

    proxies = set()
    urls = [u for u in PROXY_SOURCES if 'proxy-list.download' in u]

    tasks = [fetch_text(url, session) for url in urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    for url, text in zip(urls, results):
        if isinstance(text, str) and text:
            # 判断协议
            proto = 'http'
            if 'socks4' in url:
                proto = 'socks4'
            elif 'socks5' in url:
                proto = 'socks5'
            p = parse_ip_port(text, proto)
            proxies.update(p)
            logger.debug(f"  {url}: got {len(p)} proxies")

    return list(proxies)


async def fetch_all_proxies():
    """并发从所有源爬取代理"""
    import aiohttp
    async with aiohttp.ClientSession(
        headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'},
        timeout=aiohttp.ClientTimeout(total=20)
    ) as session:
        results = await asyncio.gather(
            fetch_from_github_lists(session),
            fetch_from_proxyscrape(session),
            fetch_from_proxy_list_download(session),
            return_exceptions=True
        )

    all_proxies = set()
    for r in results:
        if isinstance(r, list):
            all_proxies.update(r)

    logger.info(f"Total fetched: {len(all_proxies)} unique proxies")
    return list(all_proxies)


def normalize_proxy(proto, addr):
    """规范化代理格式"""
    proto = proto.lower()
    if proto in ('http', 'https', 'socks4', 'socks5'):
        return proto, addr
    # 默认 HTTP
    return 'http', addr