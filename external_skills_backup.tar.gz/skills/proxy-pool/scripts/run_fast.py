#!/usr/bin/env python3
"""快速入口：代理抓取+验证（目标 < 10 分钟）"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
exec(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), '..', '..', 'scripts', 'proxy_10min_final.py')).read())
