---
name: mcp-connection-troubleshooting
description: Use when MCP servers fail to connect, stdio closes, desktop-control or web-search are unavailable, Chrome MCP tools need enabling, or local wrappers are needed.
---

# MCP Connection Troubleshooting

## Overview

MCP failures on this machine are often environment/transport problems, not missing capability. Prefer fixing the server startup chain, then create a local wrapper when the built-in stdio server repeatedly exits.

## Current Known Good Choices

| Capability | Preferred server | Notes |
|---|---|---|
| Desktop screenshot/monitoring | `screen-monitor` | Uses verified `gnome-screenshot` backend |
| Desktop mouse/keyboard/screen size | `desktop-control-local` | Built-in `desktop-control` stdio closed in this GNOME Wayland/Xwayland environment |
| Web/news search via MCP | `web-search-local` | Built-in `web-search` stdio closed; local wrapper works |
| Browser debugging / page snapshots | `chrome-devtools` | Uses Node 22 `/usr/local/bin/npx` and Chrome DevTools MCP |
| Real Chrome extension context | `chrome-browser` | Requires mcp-chrome extension + native messaging + `127.0.0.1:12306/mcp` |

## Diagnostic Flow

1. List MCP servers with `list_mcp_servers`.
2. Connect the target server with `connect_mcp_server`.
3. If it fails, inspect logs with `get_session_logs(level="ERROR")`.
4. For stdio servers, test the command directly with the same interpreter/environment.
5. If built-in stdio exits with `Connection closed`, create or use a `*-local` wrapper using the OpenAkita venv Python.
6. Reload MCP configuration with `reload_mcp_servers`, then connect again.
7. Verify with a minimal tool call, not just a successful connection.

## Known Fixes

### desktop-control

Built-in `desktop-control` may close under Ubuntu GNOME Wayland/Xwayland unless the MCP subprocess gets the active graphics session variables.

Use `desktop-control-local` with environment like:

```text
DISPLAY=:0
XDG_SESSION_TYPE=wayland
XDG_CURRENT_DESKTOP=ubuntu:GNOME
WAYLAND_DISPLAY=wayland-0
XDG_RUNTIME_DIR=/run/user/1000
DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
XAUTHORITY=/run/user/1000/.mutter-Xwaylandauth.*
PYAUTOGUI_USE_X11=1
```

Validated minimal test: `get_screen_size` returns `1920x1080`.

For screenshots, still prefer `screen-monitor`, not `desktop-control`.

### web-search

Built-in `web-search` stdio may close even after dependencies are installed. Use `web-search-local`, launched with:

```text
/home/sesens/.openakita/venv/bin/python
```

and a wrapper script in `data/mcp_servers/`.

Validated minimal test: `web_search` returns DuckDuckGo results.

### chrome-devtools

Use Node 20.19+; this machine was fixed with Node `v22.22.2` and `/usr/local/bin/npx`.

Config pattern:

```json
{
  "transport": "stdio",
  "command": "/usr/local/bin/npx",
  "args": ["-y", "chrome-devtools-mcp@latest", "--autoConnect"]
}
```

Validated minimal test: `list_pages` or `take_snapshot` works.

### chrome-browser

`chrome-browser` is the mcp-chrome extension HTTP endpoint:

```text
http://127.0.0.1:12306/mcp
```

It needs all of these:

- Chrome/Chromium installed and running.
- mcp-chrome extension unpacked/installed.
- Native messaging host registered, usually `com.chromemcp.nativehost`.
- The extension has been connected so the local service listens on `127.0.0.1:12306`.

If `127.0.0.1:12306` is not listening, MCP connection cannot work even if the config exists.

## Common Mistakes

- Treating “server listed” as “server usable”. Always run a minimal tool call.
- Repeatedly trying the built-in stdio server after it closes; switch to the local wrapper after one root-cause check.
- Forgetting GNOME Wayland/Xwayland environment variables for desktop automation.
- Expecting `chrome-browser` to work without the Chrome extension being connected.
- Using `desktop-control` for screenshots when `screen-monitor` is more reliable here.
