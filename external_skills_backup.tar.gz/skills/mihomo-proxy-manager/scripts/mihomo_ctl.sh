#!/usr/bin/env bash
set -euo pipefail

CONFIG_DIR="${MIHOMO_CONFIG_DIR:-$HOME/.config/mihomo-akita}"
CONFIG_FILE="${MIHOMO_CONFIG_FILE:-$CONFIG_DIR/config.yaml}"
PID_FILE="${MIHOMO_PID_FILE:-$CONFIG_DIR/mihomo.pid}"
LOG_FILE="${MIHOMO_LOG_FILE:-$CONFIG_DIR/logs/mihomo.log}"
MIHOMO_BIN="${MIHOMO_BIN:-mihomo}"

mkdir -p "$CONFIG_DIR/logs"

cmd="${1:-status}"

is_running() {
  [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null
}

case "$cmd" in
  start)
    if is_running; then
      echo "mihomo already running: pid $(cat "$PID_FILE")"
      exit 0
    fi
    if [[ ! -f "$CONFIG_FILE" ]]; then
      echo "config not found: $CONFIG_FILE" >&2
      echo "run generate_config.py first" >&2
      exit 2
    fi
    if ! command -v "$MIHOMO_BIN" >/dev/null 2>&1; then
      echo "mihomo binary not found: $MIHOMO_BIN" >&2
      echo "Install mihomo core or set MIHOMO_BIN=/path/to/mihomo" >&2
      exit 3
    fi
    nohup "$MIHOMO_BIN" -d "$CONFIG_DIR" >"$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    sleep 1
    if is_running; then
      echo "started mihomo pid $(cat "$PID_FILE")"
      echo "log: $LOG_FILE"
    else
      echo "failed to start; tail log:" >&2
      tail -n 80 "$LOG_FILE" >&2 || true
      exit 4
    fi
    ;;
  stop)
    if is_running; then
      kill "$(cat "$PID_FILE")" || true
      sleep 1
      rm -f "$PID_FILE"
      echo "stopped"
    else
      rm -f "$PID_FILE"
      echo "not running"
    fi
    ;;
  restart)
    "$0" stop
    "$0" start
    ;;
  status)
    if is_running; then
      echo "running pid $(cat "$PID_FILE")"
    else
      echo "not running"
    fi
    echo "config: $CONFIG_FILE"
    echo "log: $LOG_FILE"
    ;;
  logs)
    tail -n "${2:-120}" "$LOG_FILE" || true
    ;;
  *)
    echo "Usage: $0 {start|stop|restart|status|logs [N]}" >&2
    exit 64
    ;;
esac
