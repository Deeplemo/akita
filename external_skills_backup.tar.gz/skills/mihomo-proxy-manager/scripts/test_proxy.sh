#!/usr/bin/env bash
set -euo pipefail

MIXED_PORT="${MIHOMO_MIXED_PORT:-7890}"
TEST_URL="${TEST_URL:-http://www.gstatic.com/generate_204}"
TIMEOUT="${TIMEOUT:-8}"

if ! command -v curl >/dev/null 2>&1; then
  echo "curl not found" >&2
  exit 3
fi

echo "Testing HTTP proxy on 127.0.0.1:$MIXED_PORT ..."
code=$(curl -x "http://127.0.0.1:$MIXED_PORT" -L -sS -o /dev/null -w '%{http_code}' --max-time "$TIMEOUT" "$TEST_URL" || true)
echo "HTTP status: $code"

case "$code" in
  204|200|301|302) echo "proxy looks usable"; exit 0 ;;
  000) echo "proxy test failed: connection/timeout" >&2; exit 2 ;;
  *) echo "proxy returned unexpected status: $code" >&2; exit 1 ;;
esac
