#!/usr/bin/env python3
"""Inspect or switch mihomo proxy group via external-controller API."""
from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request


def request(base: str, path: str, secret: str | None, method: str = "GET", body: dict | None = None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(base.rstrip("/") + path, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if secret:
        req.add_header("Authorization", f"Bearer {secret}")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            raw = r.read().decode("utf-8")
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "ignore")
        raise SystemExit(f"HTTP {e.code}: {msg}")


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--base", default="http://127.0.0.1:9090")
    p.add_argument("--secret", default=None)
    p.add_argument("--group", default="SELECT")
    p.add_argument("--node", default=None, help="Node name to switch to; omit to list group")
    args = p.parse_args()

    if args.node:
      request(args.base, f"/proxies/{args.group}", args.secret, "PUT", {"name": args.node})
      print(f"Switched {args.group} -> {args.node}")
      return 0

    data = request(args.base, "/proxies", args.secret)
    proxies = data.get("proxies", {}) if isinstance(data, dict) else {}
    group = proxies.get(args.group)
    if not group:
        print(f"Group not found: {args.group}", file=sys.stderr)
        print("Available groups:", ", ".join(k for k, v in proxies.items() if isinstance(v, dict) and v.get("all")))
        return 2
    print(json.dumps({
        "name": args.group,
        "now": group.get("now"),
        "all": group.get("all", []),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
