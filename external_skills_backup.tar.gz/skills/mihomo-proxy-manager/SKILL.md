---
name: mihomo-proxy-manager
description: Use when the user wants a lightweight command-line alternative to Clash Verge on Linux, using a subscription URL with mihomo/Clash.Meta core, system proxy, optional TUN, systemd, health checks, or node switching without a GUI client.
---

# Mihomo Proxy Manager

## Overview

This skill manages a lightweight Clash-Verge-like proxy connection without installing Clash Verge GUI. It uses `mihomo` core directly, a generated YAML config, and optional systemd service scripts.

Default mode is **safe user-mode mixed proxy** on `127.0.0.1:7890` to avoid breaking routing. TUN/global-VPN mode is intentionally opt-in because it needs elevated network permissions and can interrupt connectivity if misconfigured.

## When to Use

Use this when:
- The user has a legal proxy subscription URL and wants CLI-only connection.
- The user wants lower resource use than Clash Verge.
- The environment is Ubuntu/Linux desktop or server.
- OpenAkita should manage start/stop/status/test/update of the proxy.
- The user asks for “不用下载 Clash Verge”, “订阅连接”, “轻量代理”, “VPN-like”, “mihomo”, “Clash.Meta”.

Do **not** use for illegal access, credential theft, bypassing organizational controls, or unauthorized network activity.

## Recommended Architecture

| Layer | Choice | Reason |
|---|---|---|
| Core | mihomo | Best compatibility with Clash subscriptions and proxy-providers |
| Default inbound | mixed-port `127.0.0.1:7890` | Lightweight, no root required for normal proxy use |
| Service | systemd user or system service | Stable unattended operation |
| TUN | disabled by default | Requires root/CAP_NET_ADMIN and careful DNS/routing |
| Node control | external-controller `127.0.0.1:9090` | Can switch/test nodes by API |

## Files

```text
skills/mihomo-proxy-manager/
├── SKILL.md
└── scripts/
    ├── generate_config.py
    ├── mihomo_ctl.sh
    ├── test_proxy.sh
    └── switch_node.py
```

Generated runtime config defaults to:

```text
~/.config/mihomo-akita/
├── config.yaml
├── providers/
└── logs/
```

## Quick Start

1. Generate config from a subscription URL:

```bash
python scripts/generate_config.py --subscription-url 'https://example/sub' --out ~/.config/mihomo-akita/config.yaml
```

2. Put `mihomo` binary on PATH or specify it:

```bash
MIHOMO_BIN=/usr/local/bin/mihomo scripts/mihomo_ctl.sh start
```

3. Test proxy:

```bash
scripts/test_proxy.sh
```

4. Use proxy in terminal:

```bash
export http_proxy=http://127.0.0.1:7890
export https_proxy=http://127.0.0.1:7890
export all_proxy=socks5://127.0.0.1:7890
```

## Important Rules

- Keep subscription URLs out of logs where possible; they often contain tokens.
- Start with mixed-port mode first. Enable TUN only after normal proxy mode works.
- Always preserve a recovery path before enabling global routing.
- If using systemd service with TUN, prefer a root/system service and review DNS/routing config first.

## Common Mistakes

| Mistake | Fix |
|---|---|
| Treating Clash Verge as required | Use mihomo core directly; GUI is only a frontend |
| Enabling TUN immediately | First verify `127.0.0.1:7890` works |
| Logging subscription URL | Store in private file/env and redact logs |
| Assuming all subscriptions are compatible | Clash YAML works best; others may need conversion |
| Breaking DNS with TUN | Configure mihomo DNS carefully and keep fallback recovery |
