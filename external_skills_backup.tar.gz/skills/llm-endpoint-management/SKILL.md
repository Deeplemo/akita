---
name: llm-endpoint-management
description: Use when adding, deleting, prioritizing, testing, or repairing LLM endpoints, API keys, provider configs, or model fallback order.
---

# LLM Endpoint Management

## Overview

Manage LLM endpoints defensively. Endpoint deletion must not accidentally remove shared API key variables from `.env`, and newly added endpoints must be tested before being placed at high priority.

## Core Rules

1. Never delete or blank shared API keys just because an endpoint is removed.
2. Before deleting endpoints, inspect which `.env` variables they reference.
3. After adding endpoints, test connectivity and key availability.
4. After changing priority, verify the final endpoint order.
5. Keep at least one known-good fallback endpoint configured.

## Safe Workflow

### Before removing endpoints

- Use `system_config get` or inspect configuration to identify endpoint names and their `api_key_env` variables.
- If multiple endpoints share a variable like `DASHSCOPE_API_KEY`, remove only the endpoint entries, not the shared key.
- If a tool proposes cleaning unused env vars, verify they are truly unused by all endpoints.

### Adding a third-party endpoint

Use `system_config add_endpoint` with:

- unique endpoint name
- provider slug
- model name
- base URL
- API key stored into `.env`
- capabilities and timeout appropriate for the provider

Then immediately call `system_config test_endpoint`.

### Prioritizing a model

Set priority lower than other endpoints, then verify ordering. Example target order from prior setup:

| Role | Example |
|---|---|
| Primary | `claws-gpt-5.5` priority `1` |
| Fallback | NVIDIA/DeepSeek endpoints priority `20+` |
| Bulk/free models | DashScope models lower priority or token-monitored |

## Known User Environment

- Third-party Claws endpoint used before: `https://api.claws.codes/v1`, model `gpt-5.5`, endpoint `claws-gpt-5.5`.
- DeepSeek V4 Pro has been used as a fallback.
- DashScope models may share `DASHSCOPE_API_KEY`; deleting endpoint entries must not remove this key.
- NVIDIA NIM endpoint may exist for OCR/vision with base URL `https://integrate.api.nvidia.com/v1`.

Do not expose API keys in normal replies. If a user pasted a key, treat it as sensitive and avoid repeating it.

## Failure Pattern to Avoid

Past failure:

1. Expired DashScope endpoints were removed.
2. The shared `DASHSCOPE_API_KEY` variable was also removed or became unavailable.
3. New DashScope endpoints referenced `DASHSCOPE_API_KEY` but the variable was missing.
4. All DashScope endpoints failed with `Missing API key` until configuration was repaired/reloaded.

Prevention:

- Snapshot endpoint/key mapping before deletion.
- Preserve shared key variables unless the user explicitly asks to revoke the key.
- After changes, run endpoint tests and reload config if needed.

## Quick Reference

| Task | Tool |
|---|---|
| View config | `system_config(action="get", category="LLM")` |
| Add endpoint | `system_config(action="add_endpoint", endpoint={...})` |
| Remove endpoint | `system_config(action="remove_endpoint", endpoint_name="...")` |
| Test endpoint | `system_config(action="test_endpoint", endpoint_name="...")` |
| Change provider registry | `system_config(action="manage_provider", ...)` |

## Common Mistakes

- Repeating or logging raw API keys in chat.
- Assuming a restart is required before checking hot-reload state.
- Removing `.env` keys as “cleanup” while other endpoints still reference them.
- Putting an untested endpoint at priority 1.
- Leaving only broken high-priority endpoints, causing every reply to fail before fallback can run.
